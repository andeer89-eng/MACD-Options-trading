import React, { useState, useEffect } from 'react';
import { Plus, Trash2, X } from 'lucide-react';
// Fix (2026-11-13 audit): this panel (mounted inside LiveScanner) used to read/write
// './watchlist' — a separate, older store (key 'trullas_watchlists') — while the
// dedicated "Watchlists" tab (WatchlistManagerView.tsx) reads/writes
// './watchlistManager' (key 'trullas_watchlists_v1'). Two stores meant a symbol
// added here never showed up on the Watchlists tab and vice versa — a real data
// silo, not just a naming overlap. Now both read/write the same module.
import {
  Watchlist,
  loadWatchlists,
  createWatchlist,
  deleteWatchlist,
  addSymbolsToWatchlist,
  removeSymbolFromWatchlist,
} from '../utils/watchlistManager';

interface WatchlistManagerProps {
  onWatchlistSelect: (symbols: string[] | null) => void;
}

export const WatchlistManager: React.FC<WatchlistManagerProps> = ({ onWatchlistSelect }) => {
  const [watchlists, setWatchlists] = useState<Watchlist[]>([]);
  const [newName, setNewName] = useState('');
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [newSymbol, setNewSymbol] = useState('');

  useEffect(() => {
    setWatchlists(loadWatchlists());
  }, []);

  const handleCreate = () => {
    if (newName.trim()) {
      const { updatedWatchlists } = createWatchlist(watchlists, newName);
      setWatchlists(updatedWatchlists);
      setNewName('');
    }
  };

  const handleDelete = (id: string) => {
    // Default (starter) watchlists are intentionally protected from deletion by
    // watchlistManager.ts unless force=true — same rule the Watchlists tab follows.
    const updated = deleteWatchlist(watchlists, id);
    setWatchlists(updated);
    if (selectedId === id) {
      setSelectedId(null);
      onWatchlistSelect(null);
    }
  };

  const handleAddSymbol = (id: string) => {
    if (newSymbol.trim()) {
      const updated = addSymbolsToWatchlist(watchlists, id, newSymbol.toUpperCase());
      setWatchlists(updated);
      setNewSymbol('');
    }
  };

  const handleRemoveSymbol = (id: string, symbol: string) => {
    // Also fixes a latent bug in the old version: it called the store function
    // directly from the JSX onClick without ever refreshing local state, so a
    // removed symbol stayed visible in this panel until the next remount.
    const updated = removeSymbolFromWatchlist(watchlists, id, symbol);
    setWatchlists(updated);
  };

  const handleSelect = (watchlist: Watchlist) => {
    setSelectedId(watchlist.id);
    onWatchlistSelect(watchlist.symbols);
  };

  return (
    <div className="bg-gray-900 border border-gray-700 rounded-lg p-4 text-white">
      <h3 className="text-lg font-bold mb-4">Watchlist Manager</h3>
      <div className="flex gap-2 mb-4">
        <input
          value={newName}
          onChange={(e) => setNewName(e.target.value)}
          placeholder="New list name"
          className="bg-gray-800 border border-gray-700 rounded px-2 py-1 flex-grow"
        />
        <button onClick={handleCreate} className="bg-blue-600 hover:bg-blue-700 rounded p-1">
          <Plus size={20} />
        </button>
      </div>

      <div className="space-y-2">
        {watchlists.map((w, wIdx) => (
          <div key={`wl-${w.id}-${wIdx}`} className={`p-2 rounded ${selectedId === w.id ? 'bg-blue-900' : 'bg-gray-800'}`}>
            <div className="flex justify-between items-center mb-2">
              <span className="cursor-pointer" onClick={() => handleSelect(w)}>{w.name}</span>
              <button onClick={() => handleDelete(w.id)}><Trash2 size={16} className="text-red-400" /></button>
            </div>
            {selectedId === w.id && (
              <div className="space-y-1">
                <div className="flex gap-1">
                    <input
                      value={newSymbol}
                      onChange={(e) => setNewSymbol(e.target.value)}
                      placeholder="Symbol"
                      className="bg-gray-700 rounded px-1 py-0.5 text-sm w-full"
                    />
                    <button onClick={() => handleAddSymbol(w.id)} className="bg-green-600 rounded px-2">+</button>
                </div>
                <div className="flex flex-wrap gap-1 mt-2">
                  {w.symbols.map((s, sIdx) => (
                    <span key={`wl-sym-${w.id}-${s}-${sIdx}`} className="bg-gray-600 rounded px-2 py-0.5 text-xs flex items-center">
                      {s}
                      <button onClick={() => handleRemoveSymbol(w.id, s)} className="ml-1"><X size={12}/></button>
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};
