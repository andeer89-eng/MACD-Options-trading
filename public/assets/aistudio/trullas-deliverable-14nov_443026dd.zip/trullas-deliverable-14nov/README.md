# TRULLAS — pachet livrare 13-14 noiembrie 2026

## 01-documente-plan/
- `trullas-master-plan-v3.md` — planul final (actualizat cu capital/risc reglabile).
- `trullas-consolidation-map.md` — **nou**: harta reală a celor 19 tab-uri, cu
  dovezi `fișier:linie`, suprapunerile găsite, ce am reparat deja, și 2-3
  decizii care îți aparțin ție (riscul de marcă TrendSpider®, nivelul de
  fuziune UI pentru Scanner/Confluence/Action-Zones/Today).
- `trullas-audit-implementare-12-13nov.md` — auditul inițial (ce era
  implementat vs. doar schelă, în build-ul din 12 nov).
- `trullas-ai-implementation-prompt.md` — **rescris pentru Firebase** (nu mai
  presupune Postgres/Supabase) + lista completă, ordonată, de task-uri de
  consolidare rămase. Dă-l oricărui agent de coding împreună cu tot acest
  folder ca să continue exact de unde am rămas.
- `trullas-schema-v3-delta.sql`, `trullas-outcome-engine.js`,
  `trullas-today-prototype.html` — referință/context istoric (vezi §0.2 din
  prompt — SQL-ul nu se aplică direct, platforma reală e Firestore).

## 02-cod-sursa-modificat/
Fișierele sursă deja modificate și testate în build-ul tău (păstrează calea
`src/...` exact așa cum e, ca să le poți suprascrie direct în proiect):

| Fișier | Ce s-a schimbat |
|---|---|
| `src/utils/automatedPortfolio.ts` | `canTrade()` cablat ca gate real înainte de deschiderea unei poziții noi (acțiuni) |
| `src/utils/optionsAutomatedPortfolio.ts` | Același gate, adaptat pentru opțiuni (vezi comentariile din cod pentru excepția la verificarea de mărime) |
| `src/utils/masterPlanCore.ts` | Bug reparat la linia ~506 (`sizeMultiplier \|\| 1.0`) |
| `src/components/OptionsAutomatedPortfolioManager.tsx` | Bug "Exceptional Asymmetry" afișat necondiționat — acum cere n≥10 tranzacții |
| `src/components/WatchlistManager.tsx` | Rescris să folosească `watchlistManager.ts` (același store ca tab-ul Watchlists) |

**Un fișier a fost ȘTERS, nu modificat** — nu-l mai cauți în acest pachet:
`src/utils/watchlist.ts` (vechiul store de watchlist, separat și nefolosit de
nimic altceva după fix-ul de mai sus — am verificat cu grep că nimic nu-l mai
importă).

Toate cele 5 fișiere de mai sus au fost verificate cu `npx tsx --test` — 121
din 125 de teste existente trec (cele 4 eșecuri sunt de mediu: pachete reale
ca `firebase`/`@luxalgo/journal-core`, neinstalate în sandbox-ul meu izolat —
dispar după un `npm install` normal pe proiectul tău).

## Ce faci cu asta
1. Suprascrie cele 5 fișiere din `02-cod-sursa-modificat/` peste cele din
   proiectul tău (căile se potrivesc exact), șterge `src/utils/watchlist.ts`.
2. Rulează `npm install && npx tsx --test src/utils/*.test.ts` ca să confirmi.
3. Dă `trullas-ai-implementation-prompt.md` + restul din `01-documente-plan/`
   unui agent de coding pentru restul listei de consolidare (§2 din prompt).
