export interface SP500Company {
  symbol: string;
  name: string;
  sector: string;
  subIndustry?: string;
  cik?: string;
}

import { lookupGlobalCompany } from './globalTickers';

export function getCompanyName(symbol: string): string {
  if (!symbol) return '';
  const item = SP500_UNIVERSE.find((c) => c.symbol.toUpperCase() === symbol.toUpperCase());
  if (item) return item.name;
  const global = lookupGlobalCompany(symbol);
  if (global) return global.name;
  if (symbol.includes('-USD')) return `${symbol.replace('-USD', '')} Crypto`;
  if (symbol === 'SPY') return 'SPDR S&P 500 ETF Trust';
  if (symbol === 'QQQ') return 'Invesco QQQ Trust';
  if (symbol === 'IWM') return 'iShares Russell 2000 ETF';
  return symbol;
}

export const SP500_SECTORS = [
  "All Sectors",
  "Communication Services",
  "Consumer Discretionary",
  "Consumer Staples",
  "Energy",
  "Financials",
  "Health Care",
  "Industrials",
  "Information Technology",
  "Materials",
  "Real Estate",
  "Utilities"
] as const;

export const SP500_UNIVERSE: SP500Company[] = [
  {
    "symbol": "MMM",
    "name": "3M",
    "sector": "Industrials",
    "subIndustry": "Industrial Conglomerates",
    "cik": "0000066740"
  },
  {
    "symbol": "AOS",
    "name": "A. O. Smith",
    "sector": "Industrials",
    "subIndustry": "Building Products",
    "cik": "0000091142"
  },
  {
    "symbol": "ABT",
    "name": "Abbott Laboratories",
    "sector": "Health Care",
    "subIndustry": "Health Care Equipment",
    "cik": "0000001800"
  },
  {
    "symbol": "ABBV",
    "name": "AbbVie",
    "sector": "Health Care",
    "subIndustry": "Biotechnology",
    "cik": "0001551152"
  },
  {
    "symbol": "ACN",
    "name": "Accenture",
    "sector": "Information Technology",
    "subIndustry": "IT Consulting & Other Services",
    "cik": "0001467373"
  },
  {
    "symbol": "ADBE",
    "name": "Adobe Inc.",
    "sector": "Information Technology",
    "subIndustry": "Application Software",
    "cik": "0000796343"
  },
  {
    "symbol": "AMD",
    "name": "Advanced Micro Devices",
    "sector": "Information Technology",
    "subIndustry": "Semiconductors",
    "cik": "0000002488"
  },
  {
    "symbol": "AES",
    "name": "AES Corporation",
    "sector": "Utilities",
    "subIndustry": "Independent Power Producers & Energy Traders",
    "cik": "0000874761"
  },
  {
    "symbol": "AFL",
    "name": "Aflac",
    "sector": "Financials",
    "subIndustry": "Life & Health Insurance",
    "cik": "0000004977"
  },
  {
    "symbol": "A",
    "name": "Agilent Technologies",
    "sector": "Health Care",
    "subIndustry": "Life Sciences Tools & Services",
    "cik": "0001090872"
  },
  {
    "symbol": "APD",
    "name": "Air Products",
    "sector": "Materials",
    "subIndustry": "Industrial Gases",
    "cik": "0000002969"
  },
  {
    "symbol": "ABNB",
    "name": "Airbnb",
    "sector": "Consumer Discretionary",
    "subIndustry": "Hotels, Resorts & Cruise Lines",
    "cik": "0001559720"
  },
  {
    "symbol": "AKAM",
    "name": "Akamai Technologies",
    "sector": "Information Technology",
    "subIndustry": "Internet Services & Infrastructure",
    "cik": "0001086222"
  },
  {
    "symbol": "ALB",
    "name": "Albemarle Corporation",
    "sector": "Materials",
    "subIndustry": "Specialty Chemicals",
    "cik": "0000915913"
  },
  {
    "symbol": "ARE",
    "name": "Alexandria Real Estate Equities",
    "sector": "Real Estate",
    "subIndustry": "Office REITs",
    "cik": "0001035443"
  },
  {
    "symbol": "ALGN",
    "name": "Align Technology",
    "sector": "Health Care",
    "subIndustry": "Health Care Supplies",
    "cik": "0001097149"
  },
  {
    "symbol": "ALLE",
    "name": "Allegion",
    "sector": "Industrials",
    "subIndustry": "Building Products",
    "cik": "0001579241"
  },
  {
    "symbol": "LNT",
    "name": "Alliant Energy",
    "sector": "Utilities",
    "subIndustry": "Electric Utilities",
    "cik": "0000352541"
  },
  {
    "symbol": "ALL",
    "name": "Allstate",
    "sector": "Financials",
    "subIndustry": "Property & Casualty Insurance",
    "cik": "0000899051"
  },
  {
    "symbol": "GOOGL",
    "name": "Alphabet Inc. (Class A)",
    "sector": "Communication Services",
    "subIndustry": "Interactive Media & Services",
    "cik": "0001652044"
  },
  {
    "symbol": "GOOG",
    "name": "Alphabet Inc. (Class C)",
    "sector": "Communication Services",
    "subIndustry": "Interactive Media & Services",
    "cik": "0001652044"
  },
  {
    "symbol": "MO",
    "name": "Altria",
    "sector": "Consumer Staples",
    "subIndustry": "Tobacco",
    "cik": "0000764180"
  },
  {
    "symbol": "AMZN",
    "name": "Amazon",
    "sector": "Consumer Discretionary",
    "subIndustry": "Broadline Retail",
    "cik": "0001018724"
  },
  {
    "symbol": "AMCR",
    "name": "Amcor",
    "sector": "Materials",
    "subIndustry": "Paper & Plastic Packaging Products & Materials",
    "cik": "0001748790"
  },
  {
    "symbol": "AEE",
    "name": "Ameren",
    "sector": "Utilities",
    "subIndustry": "Multi-Utilities",
    "cik": "0001002910"
  },
  {
    "symbol": "AEP",
    "name": "American Electric Power",
    "sector": "Utilities",
    "subIndustry": "Electric Utilities",
    "cik": "0000004904"
  },
  {
    "symbol": "AXP",
    "name": "American Express",
    "sector": "Financials",
    "subIndustry": "Consumer Finance",
    "cik": "0000004962"
  },
  {
    "symbol": "AIG",
    "name": "American International Group",
    "sector": "Financials",
    "subIndustry": "Multi-line Insurance",
    "cik": "0000005272"
  },
  {
    "symbol": "AMT",
    "name": "American Tower",
    "sector": "Real Estate",
    "subIndustry": "Telecom Tower REITs",
    "cik": "0001053507"
  },
  {
    "symbol": "AWK",
    "name": "American Water Works",
    "sector": "Utilities",
    "subIndustry": "Water Utilities",
    "cik": "0001410636"
  },
  {
    "symbol": "AMP",
    "name": "Ameriprise Financial",
    "sector": "Financials",
    "subIndustry": "Asset Management & Custody Banks",
    "cik": "0000820027"
  },
  {
    "symbol": "AME",
    "name": "Ametek",
    "sector": "Industrials",
    "subIndustry": "Electrical Components & Equipment",
    "cik": "0001037868"
  },
  {
    "symbol": "AMGN",
    "name": "Amgen",
    "sector": "Health Care",
    "subIndustry": "Biotechnology",
    "cik": "0000318154"
  },
  {
    "symbol": "APH",
    "name": "Amphenol",
    "sector": "Information Technology",
    "subIndustry": "Electronic Components",
    "cik": "0000820313"
  },
  {
    "symbol": "ADI",
    "name": "Analog Devices",
    "sector": "Information Technology",
    "subIndustry": "Semiconductors",
    "cik": "0000006281"
  },
  {
    "symbol": "AON",
    "name": "Aon plc",
    "sector": "Financials",
    "subIndustry": "Insurance Brokers",
    "cik": "0000315293"
  },
  {
    "symbol": "APA",
    "name": "APA Corporation",
    "sector": "Energy",
    "subIndustry": "Oil & Gas Exploration & Production",
    "cik": "0001841666"
  },
  {
    "symbol": "APO",
    "name": "Apollo Global Management",
    "sector": "Financials",
    "subIndustry": "Asset Management & Custody Banks",
    "cik": "0001858681"
  },
  {
    "symbol": "AAPL",
    "name": "Apple Inc.",
    "sector": "Information Technology",
    "subIndustry": "Technology Hardware, Storage & Peripherals",
    "cik": "0000320193"
  },
  {
    "symbol": "AMAT",
    "name": "Applied Materials",
    "sector": "Information Technology",
    "subIndustry": "Semiconductor Materials & Equipment",
    "cik": "0000006951"
  },
  {
    "symbol": "APP",
    "name": "AppLovin",
    "sector": "Communication Services",
    "subIndustry": "Advertising",
    "cik": "0001751008"
  },
  {
    "symbol": "APTV",
    "name": "Aptiv",
    "sector": "Consumer Discretionary",
    "subIndustry": "Automotive Parts & Equipment",
    "cik": "0001521332"
  },
  {
    "symbol": "ACGL",
    "name": "Arch Capital Group",
    "sector": "Financials",
    "subIndustry": "Property & Casualty Insurance",
    "cik": "0000947484"
  },
  {
    "symbol": "ADM",
    "name": "Archer Daniels Midland",
    "sector": "Consumer Staples",
    "subIndustry": "Agricultural Products & Services",
    "cik": "0000007084"
  },
  {
    "symbol": "ARES",
    "name": "Ares Management",
    "sector": "Financials",
    "subIndustry": "Asset Management & Custody Banks",
    "cik": "0001176948"
  },
  {
    "symbol": "ANET",
    "name": "Arista Networks",
    "sector": "Information Technology",
    "subIndustry": "Communications Equipment",
    "cik": "0001596532"
  },
  {
    "symbol": "AJG",
    "name": "Arthur J. Gallagher & Co.",
    "sector": "Financials",
    "subIndustry": "Insurance Brokers",
    "cik": "0000354190"
  },
  {
    "symbol": "AIZ",
    "name": "Assurant",
    "sector": "Financials",
    "subIndustry": "Multi-line Insurance",
    "cik": "0001267238"
  },
  {
    "symbol": "T",
    "name": "AT&T",
    "sector": "Communication Services",
    "subIndustry": "Integrated Telecommunication Services",
    "cik": "0000732717"
  },
  {
    "symbol": "ATO",
    "name": "Atmos Energy",
    "sector": "Utilities",
    "subIndustry": "Gas Utilities",
    "cik": "0000731802"
  },
  {
    "symbol": "ADSK",
    "name": "Autodesk",
    "sector": "Information Technology",
    "subIndustry": "Application Software",
    "cik": "0000769397"
  },
  {
    "symbol": "ADP",
    "name": "Automatic Data Processing",
    "sector": "Industrials",
    "subIndustry": "Human Resource & Employment Services",
    "cik": "0000008670"
  },
  {
    "symbol": "AZO",
    "name": "AutoZone",
    "sector": "Consumer Discretionary",
    "subIndustry": "Automotive Retail",
    "cik": "0000866787"
  },
  {
    "symbol": "AVY",
    "name": "Avery Dennison",
    "sector": "Materials",
    "subIndustry": "Paper & Plastic Packaging Products & Materials",
    "cik": "0000008818"
  },
  {
    "symbol": "AXON",
    "name": "Axon Enterprise",
    "sector": "Industrials",
    "subIndustry": "Aerospace & Defense",
    "cik": "0001069183"
  },
  {
    "symbol": "BKR",
    "name": "Baker Hughes",
    "sector": "Energy",
    "subIndustry": "Oil & Gas Equipment & Services",
    "cik": "0001701605"
  },
  {
    "symbol": "BALL",
    "name": "Ball Corporation",
    "sector": "Materials",
    "subIndustry": "Metal, Glass & Plastic Containers",
    "cik": "0000009389"
  },
  {
    "symbol": "BAC",
    "name": "Bank of America",
    "sector": "Financials",
    "subIndustry": "Diversified Banks",
    "cik": "0000070858"
  },
  {
    "symbol": "BAX",
    "name": "Baxter International",
    "sector": "Health Care",
    "subIndustry": "Health Care Equipment",
    "cik": "0000010456"
  },
  {
    "symbol": "BDX",
    "name": "Becton Dickinson",
    "sector": "Health Care",
    "subIndustry": "Health Care Equipment",
    "cik": "0000010795"
  },
  {
    "symbol": "BRK.B",
    "name": "Berkshire Hathaway",
    "sector": "Financials",
    "subIndustry": "Multi-Sector Holdings",
    "cik": "0001067983"
  },
  {
    "symbol": "BBY",
    "name": "Best Buy",
    "sector": "Consumer Discretionary",
    "subIndustry": "Computer & Electronics Retail",
    "cik": "0000764478"
  },
  {
    "symbol": "TECH",
    "name": "Bio-Techne",
    "sector": "Health Care",
    "subIndustry": "Life Sciences Tools & Services",
    "cik": "0000842023"
  },
  {
    "symbol": "BIIB",
    "name": "Biogen",
    "sector": "Health Care",
    "subIndustry": "Biotechnology",
    "cik": "0000875045"
  },
  {
    "symbol": "BLK",
    "name": "BlackRock",
    "sector": "Financials",
    "subIndustry": "Asset Management & Custody Banks",
    "cik": "0002012383"
  },
  {
    "symbol": "BX",
    "name": "Blackstone Inc.",
    "sector": "Financials",
    "subIndustry": "Asset Management & Custody Banks",
    "cik": "0001393818"
  },
  {
    "symbol": "XYZ",
    "name": "Block, Inc.",
    "sector": "Financials",
    "subIndustry": "Transaction & Payment Processing Services",
    "cik": "0001512673"
  },
  {
    "symbol": "BE",
    "name": "Bloom Energy",
    "sector": "Industrials",
    "subIndustry": "Electrical Components & Equipment",
    "cik": "0001664703"
  },
  {
    "symbol": "BNY",
    "name": "BNY Mellon",
    "sector": "Financials",
    "subIndustry": "Asset Management & Custody Banks",
    "cik": "0001390777"
  },
  {
    "symbol": "BA",
    "name": "Boeing",
    "sector": "Industrials",
    "subIndustry": "Aerospace & Defense",
    "cik": "0000012927"
  },
  {
    "symbol": "BKNG",
    "name": "Booking Holdings",
    "sector": "Consumer Discretionary",
    "subIndustry": "Hotels, Resorts & Cruise Lines",
    "cik": "0001075531"
  },
  {
    "symbol": "BSX",
    "name": "Boston Scientific",
    "sector": "Health Care",
    "subIndustry": "Health Care Equipment",
    "cik": "0000885725"
  },
  {
    "symbol": "BMY",
    "name": "Bristol Myers Squibb",
    "sector": "Health Care",
    "subIndustry": "Pharmaceuticals",
    "cik": "0000014272"
  },
  {
    "symbol": "AVGO",
    "name": "Broadcom",
    "sector": "Information Technology",
    "subIndustry": "Semiconductors",
    "cik": "0001730168"
  },
  {
    "symbol": "BR",
    "name": "Broadridge Financial Solutions",
    "sector": "Industrials",
    "subIndustry": "Data Processing & Outsourced Services",
    "cik": "0001383312"
  },
  {
    "symbol": "BRO",
    "name": "Brown & Brown",
    "sector": "Financials",
    "subIndustry": "Insurance Brokers",
    "cik": "0000079282"
  },
  {
    "symbol": "BF.B",
    "name": "Brown\u2013Forman",
    "sector": "Consumer Staples",
    "subIndustry": "Distillers & Vintners",
    "cik": "0000014693"
  },
  {
    "symbol": "BG",
    "name": "Bunge Global",
    "sector": "Consumer Staples",
    "subIndustry": "Agricultural Products & Services",
    "cik": "0001996862"
  },
  {
    "symbol": "BXP",
    "name": "BXP, Inc.",
    "sector": "Real Estate",
    "subIndustry": "Office REITs",
    "cik": "0001037540"
  },
  {
    "symbol": "CHRW",
    "name": "C.H. Robinson",
    "sector": "Industrials",
    "subIndustry": "Air Freight & Logistics",
    "cik": "0001043277"
  },
  {
    "symbol": "CDNS",
    "name": "Cadence Design Systems",
    "sector": "Information Technology",
    "subIndustry": "Application Software",
    "cik": "0000813672"
  },
  {
    "symbol": "CPT",
    "name": "Camden Property Trust",
    "sector": "Real Estate",
    "subIndustry": "Multi-Family Residential REITs",
    "cik": "0000906345"
  },
  {
    "symbol": "COF",
    "name": "Capital One",
    "sector": "Financials",
    "subIndustry": "Consumer Finance",
    "cik": "0000927628"
  },
  {
    "symbol": "CAH",
    "name": "Cardinal Health",
    "sector": "Health Care",
    "subIndustry": "Health Care Distributors",
    "cik": "0000721371"
  },
  {
    "symbol": "CCL",
    "name": "Carnival Corporation",
    "sector": "Consumer Discretionary",
    "subIndustry": "Hotels, Resorts & Cruise Lines",
    "cik": "0000815097"
  },
  {
    "symbol": "CARR",
    "name": "Carrier Global",
    "sector": "Industrials",
    "subIndustry": "Building Products",
    "cik": "0001783180"
  },
  {
    "symbol": "CVNA",
    "name": "Carvana",
    "sector": "Consumer Discretionary",
    "subIndustry": "Automotive Retail",
    "cik": "0001690820"
  },
  {
    "symbol": "CASY",
    "name": "Casey's",
    "sector": "Consumer Staples",
    "subIndustry": "Food Retail",
    "cik": "0000726958"
  },
  {
    "symbol": "CAT",
    "name": "Caterpillar Inc.",
    "sector": "Industrials",
    "subIndustry": "Construction Machinery & Heavy Transportation Equipment",
    "cik": "0000018230"
  },
  {
    "symbol": "CBOE",
    "name": "Cboe Global Markets",
    "sector": "Financials",
    "subIndustry": "Financial Exchanges & Data",
    "cik": "0001374310"
  },
  {
    "symbol": "CBRE",
    "name": "CBRE Group",
    "sector": "Real Estate",
    "subIndustry": "Real Estate Services",
    "cik": "0001138118"
  },
  {
    "symbol": "CDW",
    "name": "CDW Corporation",
    "sector": "Information Technology",
    "subIndustry": "Technology Distributors",
    "cik": "0001402057"
  },
  {
    "symbol": "COR",
    "name": "Cencora",
    "sector": "Health Care",
    "subIndustry": "Health Care Distributors",
    "cik": "0001140859"
  },
  {
    "symbol": "CNC",
    "name": "Centene Corporation",
    "sector": "Health Care",
    "subIndustry": "Managed Health Care",
    "cik": "0001071739"
  },
  {
    "symbol": "CNP",
    "name": "CenterPoint Energy",
    "sector": "Utilities",
    "subIndustry": "Multi-Utilities",
    "cik": "0001130310"
  },
  {
    "symbol": "CF",
    "name": "CF Industries",
    "sector": "Materials",
    "subIndustry": "Fertilizers & Agricultural Chemicals",
    "cik": "0001324404"
  },
  {
    "symbol": "CRL",
    "name": "Charles River Laboratories",
    "sector": "Health Care",
    "subIndustry": "Life Sciences Tools & Services",
    "cik": "0001100682"
  },
  {
    "symbol": "SCHW",
    "name": "Charles Schwab Corporation",
    "sector": "Financials",
    "subIndustry": "Investment Banking & Brokerage",
    "cik": "0000316709"
  },
  {
    "symbol": "CHTR",
    "name": "Charter Communications",
    "sector": "Communication Services",
    "subIndustry": "Cable & Satellite",
    "cik": "0001091667"
  },
  {
    "symbol": "CVX",
    "name": "Chevron Corporation",
    "sector": "Energy",
    "subIndustry": "Integrated Oil & Gas",
    "cik": "0000093410"
  },
  {
    "symbol": "CMG",
    "name": "Chipotle Mexican Grill",
    "sector": "Consumer Discretionary",
    "subIndustry": "Restaurants",
    "cik": "0001058090"
  },
  {
    "symbol": "CB",
    "name": "Chubb Limited",
    "sector": "Financials",
    "subIndustry": "Property & Casualty Insurance",
    "cik": "0000896159"
  },
  {
    "symbol": "CHD",
    "name": "Church & Dwight",
    "sector": "Consumer Staples",
    "subIndustry": "Household Products",
    "cik": "0000313927"
  },
  {
    "symbol": "CIEN",
    "name": "Ciena",
    "sector": "Information Technology",
    "subIndustry": "Communications Equipment",
    "cik": "0000936395"
  },
  {
    "symbol": "CI",
    "name": "Cigna",
    "sector": "Health Care",
    "subIndustry": "Health Care Services",
    "cik": "0001739940"
  },
  {
    "symbol": "CINF",
    "name": "Cincinnati Financial",
    "sector": "Financials",
    "subIndustry": "Property & Casualty Insurance",
    "cik": "0000020286"
  },
  {
    "symbol": "CTAS",
    "name": "Cintas",
    "sector": "Industrials",
    "subIndustry": "Diversified Support Services",
    "cik": "0000723254"
  },
  {
    "symbol": "CSCO",
    "name": "Cisco",
    "sector": "Information Technology",
    "subIndustry": "Communications Equipment",
    "cik": "0000858877"
  },
  {
    "symbol": "C",
    "name": "Citigroup",
    "sector": "Financials",
    "subIndustry": "Diversified Banks",
    "cik": "0000831001"
  },
  {
    "symbol": "CFG",
    "name": "Citizens Financial Group",
    "sector": "Financials",
    "subIndustry": "Regional Banks",
    "cik": "0000759944"
  },
  {
    "symbol": "CLX",
    "name": "Clorox",
    "sector": "Consumer Staples",
    "subIndustry": "Household Products",
    "cik": "0000021076"
  },
  {
    "symbol": "CME",
    "name": "CME Group",
    "sector": "Financials",
    "subIndustry": "Financial Exchanges & Data",
    "cik": "0001156375"
  },
  {
    "symbol": "CMS",
    "name": "CMS Energy",
    "sector": "Utilities",
    "subIndustry": "Multi-Utilities",
    "cik": "0000811156"
  },
  {
    "symbol": "KO",
    "name": "Coca-Cola Company (The)",
    "sector": "Consumer Staples",
    "subIndustry": "Soft Drinks & Non-alcoholic Beverages",
    "cik": "0000021344"
  },
  {
    "symbol": "CTSH",
    "name": "Cognizant",
    "sector": "Information Technology",
    "subIndustry": "IT Consulting & Other Services",
    "cik": "0001058290"
  },
  {
    "symbol": "COHR",
    "name": "Coherent Corp.",
    "sector": "Information Technology",
    "subIndustry": "Electronic Components",
    "cik": "0000820318"
  },
  {
    "symbol": "COIN",
    "name": "Coinbase",
    "sector": "Financials",
    "subIndustry": "Financial Exchanges & Data",
    "cik": "0001679788"
  },
  {
    "symbol": "CL",
    "name": "Colgate-Palmolive",
    "sector": "Consumer Staples",
    "subIndustry": "Household Products",
    "cik": "0000021665"
  },
  {
    "symbol": "CMCSA",
    "name": "Comcast",
    "sector": "Communication Services",
    "subIndustry": "Cable & Satellite",
    "cik": "0001166691"
  },
  {
    "symbol": "FIX",
    "name": "Comfort Systems USA",
    "sector": "Industrials",
    "subIndustry": "Construction & Engineering",
    "cik": "0001035983"
  },
  {
    "symbol": "COP",
    "name": "ConocoPhillips",
    "sector": "Energy",
    "subIndustry": "Oil & Gas Exploration & Production",
    "cik": "0001163165"
  },
  {
    "symbol": "ED",
    "name": "Consolidated Edison",
    "sector": "Utilities",
    "subIndustry": "Multi-Utilities",
    "cik": "0001047862"
  },
  {
    "symbol": "STZ",
    "name": "Constellation Brands",
    "sector": "Consumer Staples",
    "subIndustry": "Distillers & Vintners",
    "cik": "0000016918"
  },
  {
    "symbol": "CEG",
    "name": "Constellation Energy",
    "sector": "Utilities",
    "subIndustry": "Electric Utilities",
    "cik": "0001868275"
  },
  {
    "symbol": "COO",
    "name": "Cooper Companies (The)",
    "sector": "Health Care",
    "subIndustry": "Health Care Supplies",
    "cik": "0000711404"
  },
  {
    "symbol": "CPRT",
    "name": "Copart",
    "sector": "Industrials",
    "subIndustry": "Diversified Support Services",
    "cik": "0000900075"
  },
  {
    "symbol": "GLW",
    "name": "Corning Inc.",
    "sector": "Information Technology",
    "subIndustry": "Electronic Components",
    "cik": "0000024741"
  },
  {
    "symbol": "CPAY",
    "name": "Corpay",
    "sector": "Financials",
    "subIndustry": "Transaction & Payment Processing Services",
    "cik": "0001175454"
  },
  {
    "symbol": "CSGP",
    "name": "CoStar Group",
    "sector": "Real Estate",
    "subIndustry": "Real Estate Services",
    "cik": "0001057352"
  },
  {
    "symbol": "COST",
    "name": "Costco",
    "sector": "Consumer Staples",
    "subIndustry": "Consumer Staples Merchandise Retail",
    "cik": "0000909832"
  },
  {
    "symbol": "CRH",
    "name": "CRH plc",
    "sector": "Materials",
    "subIndustry": "Construction Materials",
    "cik": "0000849395"
  },
  {
    "symbol": "CRWD",
    "name": "CrowdStrike",
    "sector": "Information Technology",
    "subIndustry": "Systems Software",
    "cik": "0001535527"
  },
  {
    "symbol": "CCI",
    "name": "Crown Castle",
    "sector": "Real Estate",
    "subIndustry": "Telecom Tower REITs",
    "cik": "0001051470"
  },
  {
    "symbol": "CSX",
    "name": "CSX Corporation",
    "sector": "Industrials",
    "subIndustry": "Rail Transportation",
    "cik": "0000277948"
  },
  {
    "symbol": "CMI",
    "name": "Cummins",
    "sector": "Industrials",
    "subIndustry": "Construction Machinery & Heavy Transportation Equipment",
    "cik": "0000026172"
  },
  {
    "symbol": "CVS",
    "name": "CVS Health",
    "sector": "Health Care",
    "subIndustry": "Health Care Services",
    "cik": "0000064803"
  },
  {
    "symbol": "DHR",
    "name": "Danaher Corporation",
    "sector": "Health Care",
    "subIndustry": "Life Sciences Tools & Services",
    "cik": "0000313616"
  },
  {
    "symbol": "DRI",
    "name": "Darden Restaurants",
    "sector": "Consumer Discretionary",
    "subIndustry": "Restaurants",
    "cik": "0000940944"
  },
  {
    "symbol": "DDOG",
    "name": "Datadog",
    "sector": "Information Technology",
    "subIndustry": "Application Software",
    "cik": "0001561550"
  },
  {
    "symbol": "DVA",
    "name": "DaVita",
    "sector": "Health Care",
    "subIndustry": "Health Care Services",
    "cik": "0000927066"
  },
  {
    "symbol": "DECK",
    "name": "Deckers Brands",
    "sector": "Consumer Discretionary",
    "subIndustry": "Footwear",
    "cik": "0000910521"
  },
  {
    "symbol": "DE",
    "name": "Deere & Company",
    "sector": "Industrials",
    "subIndustry": "Agricultural & Farm Machinery",
    "cik": "0000315189"
  },
  {
    "symbol": "DELL",
    "name": "Dell Technologies",
    "sector": "Information Technology",
    "subIndustry": "Technology Hardware, Storage & Peripherals",
    "cik": "0001571996"
  },
  {
    "symbol": "DAL",
    "name": "Delta Air Lines",
    "sector": "Industrials",
    "subIndustry": "Passenger Airlines",
    "cik": "0000027904"
  },
  {
    "symbol": "DVN",
    "name": "Devon Energy",
    "sector": "Energy",
    "subIndustry": "Oil & Gas Exploration & Production",
    "cik": "0001090012"
  },
  {
    "symbol": "DXCM",
    "name": "Dexcom",
    "sector": "Health Care",
    "subIndustry": "Health Care Equipment",
    "cik": "0001093557"
  },
  {
    "symbol": "FANG",
    "name": "Diamondback Energy",
    "sector": "Energy",
    "subIndustry": "Oil & Gas Exploration & Production",
    "cik": "0001539838"
  },
  {
    "symbol": "DLR",
    "name": "Digital Realty",
    "sector": "Real Estate",
    "subIndustry": "Data Center REITs",
    "cik": "0001297996"
  },
  {
    "symbol": "DG",
    "name": "Dollar General",
    "sector": "Consumer Staples",
    "subIndustry": "Consumer Staples Merchandise Retail",
    "cik": "0000029534"
  },
  {
    "symbol": "DLTR",
    "name": "Dollar Tree",
    "sector": "Consumer Staples",
    "subIndustry": "Consumer Staples Merchandise Retail",
    "cik": "0000935703"
  },
  {
    "symbol": "D",
    "name": "Dominion Energy",
    "sector": "Utilities",
    "subIndustry": "Multi-Utilities",
    "cik": "0000715957"
  },
  {
    "symbol": "DPZ",
    "name": "Domino's",
    "sector": "Consumer Discretionary",
    "subIndustry": "Restaurants",
    "cik": "0001286681"
  },
  {
    "symbol": "DASH",
    "name": "DoorDash",
    "sector": "Consumer Discretionary",
    "subIndustry": "Specialized Consumer Services",
    "cik": "0001792789"
  },
  {
    "symbol": "DOV",
    "name": "Dover Corporation",
    "sector": "Industrials",
    "subIndustry": "Industrial Machinery & Supplies & Components",
    "cik": "0000029905"
  },
  {
    "symbol": "DOW",
    "name": "Dow Inc.",
    "sector": "Materials",
    "subIndustry": "Commodity Chemicals",
    "cik": "0001751788"
  },
  {
    "symbol": "DHI",
    "name": "D. R. Horton",
    "sector": "Consumer Discretionary",
    "subIndustry": "Homebuilding",
    "cik": "0000882184"
  },
  {
    "symbol": "DTE",
    "name": "DTE Energy",
    "sector": "Utilities",
    "subIndustry": "Multi-Utilities",
    "cik": "0000936340"
  },
  {
    "symbol": "DUK",
    "name": "Duke Energy",
    "sector": "Utilities",
    "subIndustry": "Electric Utilities",
    "cik": "0001326160"
  },
  {
    "symbol": "DD",
    "name": "DuPont",
    "sector": "Industrials",
    "subIndustry": "Industrial Conglomerates",
    "cik": "0001666700"
  },
  {
    "symbol": "ETN",
    "name": "Eaton Corporation",
    "sector": "Industrials",
    "subIndustry": "Electrical Components & Equipment",
    "cik": "0001551182"
  },
  {
    "symbol": "EBAY",
    "name": "eBay Inc.",
    "sector": "Consumer Discretionary",
    "subIndustry": "Broadline Retail",
    "cik": "0001065088"
  },
  {
    "symbol": "ECHO",
    "name": "EchoStar",
    "sector": "Communication Services",
    "subIndustry": "Wireless Telecommunication Services",
    "cik": "0001415404"
  },
  {
    "symbol": "ECL",
    "name": "Ecolab",
    "sector": "Materials",
    "subIndustry": "Specialty Chemicals",
    "cik": "0000031462"
  },
  {
    "symbol": "EIX",
    "name": "Edison International",
    "sector": "Utilities",
    "subIndustry": "Electric Utilities",
    "cik": "0000827052"
  },
  {
    "symbol": "EW",
    "name": "Edwards Lifesciences",
    "sector": "Health Care",
    "subIndustry": "Health Care Equipment",
    "cik": "0001099800"
  },
  {
    "symbol": "ELV",
    "name": "Elevance Health",
    "sector": "Health Care",
    "subIndustry": "Managed Health Care",
    "cik": "0001156039"
  },
  {
    "symbol": "EME",
    "name": "Emcor",
    "sector": "Industrials",
    "subIndustry": "Construction & Engineering",
    "cik": "0000105634"
  },
  {
    "symbol": "EMR",
    "name": "Emerson Electric",
    "sector": "Industrials",
    "subIndustry": "Electrical Components & Equipment",
    "cik": "0000032604"
  },
  {
    "symbol": "ETR",
    "name": "Entergy",
    "sector": "Utilities",
    "subIndustry": "Electric Utilities",
    "cik": "0000065984"
  },
  {
    "symbol": "EOG",
    "name": "EOG Resources",
    "sector": "Energy",
    "subIndustry": "Oil & Gas Exploration & Production",
    "cik": "0000821189"
  },
  {
    "symbol": "EQT",
    "name": "EQT Corporation",
    "sector": "Energy",
    "subIndustry": "Oil & Gas Exploration & Production",
    "cik": "0000033213"
  },
  {
    "symbol": "EFX",
    "name": "Equifax",
    "sector": "Industrials",
    "subIndustry": "Research & Consulting Services",
    "cik": "0000033185"
  },
  {
    "symbol": "EQIX",
    "name": "Equinix",
    "sector": "Real Estate",
    "subIndustry": "Data Center REITs",
    "cik": "0001101239"
  },
  {
    "symbol": "ERIE",
    "name": "Erie Indemnity",
    "sector": "Financials",
    "subIndustry": "Insurance Brokers",
    "cik": "0000922621"
  },
  {
    "symbol": "ESS",
    "name": "Essex Property Trust",
    "sector": "Real Estate",
    "subIndustry": "Multi-Family Residential REITs",
    "cik": "0000920522"
  },
  {
    "symbol": "EL",
    "name": "Est\u00e9e Lauder Companies (The)",
    "sector": "Consumer Staples",
    "subIndustry": "Personal Care Products",
    "cik": "0001001250"
  },
  {
    "symbol": "EG",
    "name": "Everest Group",
    "sector": "Financials",
    "subIndustry": "Reinsurance",
    "cik": "0001095073"
  },
  {
    "symbol": "EVRG",
    "name": "Evergy",
    "sector": "Utilities",
    "subIndustry": "Electric Utilities",
    "cik": "0001711269"
  },
  {
    "symbol": "P",
    "name": "Everpure",
    "sector": "Information Technology",
    "subIndustry": "Technology Hardware, Storage & Peripherals",
    "cik": "0001474432"
  },
  {
    "symbol": "ES",
    "name": "Eversource Energy",
    "sector": "Utilities",
    "subIndustry": "Electric Utilities",
    "cik": "0000072741"
  },
  {
    "symbol": "EXC",
    "name": "Exelon",
    "sector": "Utilities",
    "subIndustry": "Electric Utilities",
    "cik": "0001109357"
  },
  {
    "symbol": "EXE",
    "name": "Expand Energy",
    "sector": "Energy",
    "subIndustry": "Oil & Gas Exploration & Production",
    "cik": "0000895126"
  },
  {
    "symbol": "EXPE",
    "name": "Expedia Group",
    "sector": "Consumer Discretionary",
    "subIndustry": "Hotels, Resorts & Cruise Lines",
    "cik": "0001324424"
  },
  {
    "symbol": "EXPD",
    "name": "Expeditors International",
    "sector": "Industrials",
    "subIndustry": "Air Freight & Logistics",
    "cik": "0000746515"
  },
  {
    "symbol": "EXR",
    "name": "Extra Space Storage",
    "sector": "Real Estate",
    "subIndustry": "Self-Storage REITs",
    "cik": "0001289490"
  },
  {
    "symbol": "XOM",
    "name": "ExxonMobil",
    "sector": "Energy",
    "subIndustry": "Integrated Oil & Gas",
    "cik": "0002115436"
  },
  {
    "symbol": "FFIV",
    "name": "F5, Inc.",
    "sector": "Information Technology",
    "subIndustry": "Communications Equipment",
    "cik": "0001048695"
  },
  {
    "symbol": "FDS",
    "name": "FactSet",
    "sector": "Financials",
    "subIndustry": "Financial Exchanges & Data",
    "cik": "0001013237"
  },
  {
    "symbol": "FICO",
    "name": "Fair Isaac",
    "sector": "Information Technology",
    "subIndustry": "Application Software",
    "cik": "0000814547"
  },
  {
    "symbol": "FAST",
    "name": "Fastenal",
    "sector": "Industrials",
    "subIndustry": "Trading Companies & Distributors",
    "cik": "0000815556"
  },
  {
    "symbol": "FRT",
    "name": "Federal Realty Investment Trust",
    "sector": "Real Estate",
    "subIndustry": "Retail REITs",
    "cik": "0000034903"
  },
  {
    "symbol": "FDX",
    "name": "FedEx",
    "sector": "Industrials",
    "subIndustry": "Air Freight & Logistics",
    "cik": "0001048911"
  },
  {
    "symbol": "FDXF",
    "name": "FedEx Freight",
    "sector": "Industrials",
    "subIndustry": "Cargo Ground Transportation",
    "cik": "0002082247"
  },
  {
    "symbol": "FERG",
    "name": "Ferguson Enterprises",
    "sector": "Industrials",
    "subIndustry": "Trading Companies & Distributors",
    "cik": "0002011641"
  },
  {
    "symbol": "FIS",
    "name": "Fidelity National Information Services",
    "sector": "Financials",
    "subIndustry": "Transaction & Payment Processing Services",
    "cik": "0001136893"
  },
  {
    "symbol": "FITB",
    "name": "Fifth Third Bancorp",
    "sector": "Financials",
    "subIndustry": "Regional Banks",
    "cik": "0000035527"
  },
  {
    "symbol": "FSLR",
    "name": "First Solar",
    "sector": "Information Technology",
    "subIndustry": "Semiconductors",
    "cik": "0001274494"
  },
  {
    "symbol": "FE",
    "name": "FirstEnergy",
    "sector": "Utilities",
    "subIndustry": "Electric Utilities",
    "cik": "0001031296"
  },
  {
    "symbol": "FISV",
    "name": "Fiserv",
    "sector": "Financials",
    "subIndustry": "Transaction & Payment Processing Services",
    "cik": "0000798354"
  },
  {
    "symbol": "FLEX",
    "name": "Flex Ltd.",
    "sector": "Information Technology",
    "subIndustry": "Electronic Manufacturing Services",
    "cik": "0000866374"
  },
  {
    "symbol": "F",
    "name": "Ford Motor Company",
    "sector": "Consumer Discretionary",
    "subIndustry": "Automobile Manufacturers",
    "cik": "0000037996"
  },
  {
    "symbol": "FTNT",
    "name": "Fortinet",
    "sector": "Information Technology",
    "subIndustry": "Systems Software",
    "cik": "0001262039"
  },
  {
    "symbol": "FTV",
    "name": "Fortive",
    "sector": "Industrials",
    "subIndustry": "Industrial Machinery & Supplies & Components",
    "cik": "0001659166"
  },
  {
    "symbol": "FOXA",
    "name": "Fox Corporation (Class A)",
    "sector": "Communication Services",
    "subIndustry": "Broadcasting",
    "cik": "0001754301"
  },
  {
    "symbol": "FOX",
    "name": "Fox Corporation (Class B)",
    "sector": "Communication Services",
    "subIndustry": "Broadcasting",
    "cik": "0001754301"
  },
  {
    "symbol": "BEN",
    "name": "Franklin Resources",
    "sector": "Financials",
    "subIndustry": "Asset Management & Custody Banks",
    "cik": "0000038777"
  },
  {
    "symbol": "FCX",
    "name": "Freeport-McMoRan",
    "sector": "Materials",
    "subIndustry": "Copper",
    "cik": "0000831259"
  },
  {
    "symbol": "GRMN",
    "name": "Garmin",
    "sector": "Consumer Discretionary",
    "subIndustry": "Consumer Electronics",
    "cik": "0001121788"
  },
  {
    "symbol": "IT",
    "name": "Gartner",
    "sector": "Information Technology",
    "subIndustry": "IT Consulting & Other Services",
    "cik": "0000749251"
  },
  {
    "symbol": "GE",
    "name": "GE Aerospace",
    "sector": "Industrials",
    "subIndustry": "Aerospace & Defense",
    "cik": "0000040545"
  },
  {
    "symbol": "GEHC",
    "name": "GE HealthCare",
    "sector": "Health Care",
    "subIndustry": "Health Care Equipment",
    "cik": "0001932393"
  },
  {
    "symbol": "GEV",
    "name": "GE Vernova",
    "sector": "Industrials",
    "subIndustry": "Heavy Electrical Equipment",
    "cik": "0001996810"
  },
  {
    "symbol": "GEN",
    "name": "Gen Digital",
    "sector": "Information Technology",
    "subIndustry": "Systems Software",
    "cik": "0000849399"
  },
  {
    "symbol": "GNRC",
    "name": "Generac",
    "sector": "Industrials",
    "subIndustry": "Heavy Electrical Equipment",
    "cik": "0001474735"
  },
  {
    "symbol": "GD",
    "name": "General Dynamics",
    "sector": "Industrials",
    "subIndustry": "Aerospace & Defense",
    "cik": "0000040533"
  },
  {
    "symbol": "GIS",
    "name": "General Mills",
    "sector": "Consumer Staples",
    "subIndustry": "Packaged Foods & Meats",
    "cik": "0000040704"
  },
  {
    "symbol": "GM",
    "name": "General Motors",
    "sector": "Consumer Discretionary",
    "subIndustry": "Automobile Manufacturers",
    "cik": "0001467858"
  },
  {
    "symbol": "GPC",
    "name": "Genuine Parts Company",
    "sector": "Consumer Discretionary",
    "subIndustry": "Distributors",
    "cik": "0000040987"
  },
  {
    "symbol": "GILD",
    "name": "Gilead Sciences",
    "sector": "Health Care",
    "subIndustry": "Biotechnology",
    "cik": "0000882095"
  },
  {
    "symbol": "GPN",
    "name": "Global Payments",
    "sector": "Financials",
    "subIndustry": "Transaction & Payment Processing Services",
    "cik": "0001123360"
  },
  {
    "symbol": "GL",
    "name": "Globe Life",
    "sector": "Financials",
    "subIndustry": "Life & Health Insurance",
    "cik": "0000320335"
  },
  {
    "symbol": "GDDY",
    "name": "GoDaddy",
    "sector": "Information Technology",
    "subIndustry": "Internet Services & Infrastructure",
    "cik": "0001609711"
  },
  {
    "symbol": "GS",
    "name": "Goldman Sachs",
    "sector": "Financials",
    "subIndustry": "Investment Banking & Brokerage",
    "cik": "0000886982"
  },
  {
    "symbol": "HAL",
    "name": "Halliburton",
    "sector": "Energy",
    "subIndustry": "Oil & Gas Equipment & Services",
    "cik": "0000045012"
  },
  {
    "symbol": "HIG",
    "name": "Hartford (The)",
    "sector": "Financials",
    "subIndustry": "Property & Casualty Insurance",
    "cik": "0000874766"
  },
  {
    "symbol": "HAS",
    "name": "Hasbro",
    "sector": "Consumer Discretionary",
    "subIndustry": "Leisure Products",
    "cik": "0000046080"
  },
  {
    "symbol": "HCA",
    "name": "HCA Healthcare",
    "sector": "Health Care",
    "subIndustry": "Health Care Facilities",
    "cik": "0000860730"
  },
  {
    "symbol": "DOC",
    "name": "Healthpeak Properties",
    "sector": "Real Estate",
    "subIndustry": "Health Care REITs",
    "cik": "0000765880"
  },
  {
    "symbol": "HSIC",
    "name": "Henry Schein",
    "sector": "Health Care",
    "subIndustry": "Health Care Distributors",
    "cik": "0001000228"
  },
  {
    "symbol": "HSY",
    "name": "Hershey Company (The)",
    "sector": "Consumer Staples",
    "subIndustry": "Packaged Foods & Meats",
    "cik": "0000047111"
  },
  {
    "symbol": "HPE",
    "name": "Hewlett Packard Enterprise",
    "sector": "Information Technology",
    "subIndustry": "Technology Hardware, Storage & Peripherals",
    "cik": "0001645590"
  },
  {
    "symbol": "HLT",
    "name": "Hilton Worldwide",
    "sector": "Consumer Discretionary",
    "subIndustry": "Hotels, Resorts & Cruise Lines",
    "cik": "0001585689"
  },
  {
    "symbol": "HD",
    "name": "Home Depot (The)",
    "sector": "Consumer Discretionary",
    "subIndustry": "Home Improvement Retail",
    "cik": "0000354950"
  },
  {
    "symbol": "HONA",
    "name": "Honeywell Aerospace",
    "sector": "Industrials",
    "subIndustry": "Aerospace & Defense",
    "cik": "0002089271"
  },
  {
    "symbol": "HON",
    "name": "Honeywell Technologies",
    "sector": "Industrials",
    "subIndustry": "Industrial Conglomerates",
    "cik": "0000773840"
  },
  {
    "symbol": "HRL",
    "name": "Hormel Foods",
    "sector": "Consumer Staples",
    "subIndustry": "Packaged Foods & Meats",
    "cik": "0000048465"
  },
  {
    "symbol": "HST",
    "name": "Host Hotels & Resorts",
    "sector": "Real Estate",
    "subIndustry": "Hotel & Resort REITs",
    "cik": "0001070750"
  },
  {
    "symbol": "HWM",
    "name": "Howmet Aerospace",
    "sector": "Industrials",
    "subIndustry": "Aerospace & Defense",
    "cik": "0000004281"
  },
  {
    "symbol": "HPQ",
    "name": "HP Inc.",
    "sector": "Information Technology",
    "subIndustry": "Technology Hardware, Storage & Peripherals",
    "cik": "0000047217"
  },
  {
    "symbol": "HUBB",
    "name": "Hubbell Incorporated",
    "sector": "Industrials",
    "subIndustry": "Industrial Machinery & Supplies & Components",
    "cik": "0000048898"
  },
  {
    "symbol": "HUM",
    "name": "Humana",
    "sector": "Health Care",
    "subIndustry": "Managed Health Care",
    "cik": "0000049071"
  },
  {
    "symbol": "HBAN",
    "name": "Huntington Bancshares",
    "sector": "Financials",
    "subIndustry": "Regional Banks",
    "cik": "0000049196"
  },
  {
    "symbol": "HII",
    "name": "Huntington Ingalls Industries",
    "sector": "Industrials",
    "subIndustry": "Aerospace & Defense",
    "cik": "0001501585"
  },
  {
    "symbol": "IBM",
    "name": "IBM",
    "sector": "Information Technology",
    "subIndustry": "IT Consulting & Other Services",
    "cik": "0000051143"
  },
  {
    "symbol": "IEX",
    "name": "IDEX Corporation",
    "sector": "Industrials",
    "subIndustry": "Industrial Machinery & Supplies & Components",
    "cik": "0000832101"
  },
  {
    "symbol": "IDXX",
    "name": "Idexx Laboratories",
    "sector": "Health Care",
    "subIndustry": "Health Care Equipment",
    "cik": "0000874716"
  },
  {
    "symbol": "ITW",
    "name": "Illinois Tool Works",
    "sector": "Industrials",
    "subIndustry": "Industrial Machinery & Supplies & Components",
    "cik": "0000049826"
  },
  {
    "symbol": "ILMN",
    "name": "Illumina, Inc.",
    "sector": "Health Care",
    "subIndustry": "Life Sciences Tools & Services",
    "cik": "0001110803"
  },
  {
    "symbol": "INCY",
    "name": "Incyte",
    "sector": "Health Care",
    "subIndustry": "Biotechnology",
    "cik": "0000879169"
  },
  {
    "symbol": "IR",
    "name": "Ingersoll Rand",
    "sector": "Industrials",
    "subIndustry": "Industrial Machinery & Supplies & Components",
    "cik": "0001699150"
  },
  {
    "symbol": "PODD",
    "name": "Insulet Corporation",
    "sector": "Health Care",
    "subIndustry": "Health Care Equipment",
    "cik": "0001145197"
  },
  {
    "symbol": "INTC",
    "name": "Intel",
    "sector": "Information Technology",
    "subIndustry": "Semiconductors",
    "cik": "0000050863"
  },
  {
    "symbol": "IBKR",
    "name": "Interactive Brokers",
    "sector": "Financials",
    "subIndustry": "Investment Banking & Brokerage",
    "cik": "0001381197"
  },
  {
    "symbol": "ICE",
    "name": "Intercontinental Exchange",
    "sector": "Financials",
    "subIndustry": "Financial Exchanges & Data",
    "cik": "0001571949"
  },
  {
    "symbol": "IFF",
    "name": "International Flavors & Fragrances",
    "sector": "Materials",
    "subIndustry": "Specialty Chemicals",
    "cik": "0000051253"
  },
  {
    "symbol": "IP",
    "name": "International Paper",
    "sector": "Materials",
    "subIndustry": "Paper & Plastic Packaging Products & Materials",
    "cik": "0000051434"
  },
  {
    "symbol": "INTU",
    "name": "Intuit",
    "sector": "Information Technology",
    "subIndustry": "Application Software",
    "cik": "0000896878"
  },
  {
    "symbol": "ISRG",
    "name": "Intuitive Surgical",
    "sector": "Health Care",
    "subIndustry": "Health Care Equipment",
    "cik": "0001035267"
  },
  {
    "symbol": "IVZ",
    "name": "Invesco",
    "sector": "Financials",
    "subIndustry": "Asset Management & Custody Banks",
    "cik": "0000914208"
  },
  {
    "symbol": "INVH",
    "name": "Invitation Homes",
    "sector": "Real Estate",
    "subIndustry": "Single-Family Residential REITs",
    "cik": "0001687229"
  },
  {
    "symbol": "IQV",
    "name": "IQVIA",
    "sector": "Health Care",
    "subIndustry": "Life Sciences Tools & Services",
    "cik": "0001478242"
  },
  {
    "symbol": "IRM",
    "name": "Iron Mountain",
    "sector": "Real Estate",
    "subIndustry": "Other Specialized REITs",
    "cik": "0001020569"
  },
  {
    "symbol": "JBHT",
    "name": "J.B. Hunt",
    "sector": "Industrials",
    "subIndustry": "Cargo Ground Transportation",
    "cik": "0000728535"
  },
  {
    "symbol": "JBL",
    "name": "Jabil",
    "sector": "Information Technology",
    "subIndustry": "Electronic Manufacturing Services",
    "cik": "0000898293"
  },
  {
    "symbol": "JKHY",
    "name": "Jack Henry & Associates",
    "sector": "Financials",
    "subIndustry": "Transaction & Payment Processing Services",
    "cik": "0000779152"
  },
  {
    "symbol": "J",
    "name": "Jacobs Solutions",
    "sector": "Industrials",
    "subIndustry": "Construction & Engineering",
    "cik": "0000052988"
  },
  {
    "symbol": "JNJ",
    "name": "Johnson & Johnson",
    "sector": "Health Care",
    "subIndustry": "Pharmaceuticals",
    "cik": "0000200406"
  },
  {
    "symbol": "JCI",
    "name": "Johnson Controls",
    "sector": "Industrials",
    "subIndustry": "Building Products",
    "cik": "0000833444"
  },
  {
    "symbol": "JPM",
    "name": "JPMorgan Chase",
    "sector": "Financials",
    "subIndustry": "Diversified Banks",
    "cik": "0000019617"
  },
  {
    "symbol": "KVUE",
    "name": "Kenvue",
    "sector": "Consumer Staples",
    "subIndustry": "Personal Care Products",
    "cik": "0001944048"
  },
  {
    "symbol": "KDP",
    "name": "Keurig Dr Pepper",
    "sector": "Consumer Staples",
    "subIndustry": "Soft Drinks & Non-alcoholic Beverages",
    "cik": "0001418135"
  },
  {
    "symbol": "KEY",
    "name": "KeyCorp",
    "sector": "Financials",
    "subIndustry": "Regional Banks",
    "cik": "0000091576"
  },
  {
    "symbol": "KEYS",
    "name": "Keysight Technologies",
    "sector": "Information Technology",
    "subIndustry": "Electronic Equipment & Instruments",
    "cik": "0001601046"
  },
  {
    "symbol": "KMB",
    "name": "Kimberly-Clark",
    "sector": "Consumer Staples",
    "subIndustry": "Household Products",
    "cik": "0000055785"
  },
  {
    "symbol": "KIM",
    "name": "Kimco Realty",
    "sector": "Real Estate",
    "subIndustry": "Retail REITs",
    "cik": "0000879101"
  },
  {
    "symbol": "KMI",
    "name": "Kinder Morgan",
    "sector": "Energy",
    "subIndustry": "Oil & Gas Storage & Transportation",
    "cik": "0001506307"
  },
  {
    "symbol": "KKR",
    "name": "KKR & Co.",
    "sector": "Financials",
    "subIndustry": "Asset Management & Custody Banks",
    "cik": "0001404912"
  },
  {
    "symbol": "KLAC",
    "name": "KLA Corporation",
    "sector": "Information Technology",
    "subIndustry": "Semiconductor Materials & Equipment",
    "cik": "0000319201"
  },
  {
    "symbol": "KHC",
    "name": "Kraft Heinz",
    "sector": "Consumer Staples",
    "subIndustry": "Packaged Foods & Meats",
    "cik": "0001637459"
  },
  {
    "symbol": "KR",
    "name": "Kroger",
    "sector": "Consumer Staples",
    "subIndustry": "Food Retail",
    "cik": "0000056873"
  },
  {
    "symbol": "LHX",
    "name": "L3Harris",
    "sector": "Industrials",
    "subIndustry": "Aerospace & Defense",
    "cik": "0000202058"
  },
  {
    "symbol": "LH",
    "name": "Labcorp",
    "sector": "Health Care",
    "subIndustry": "Health Care Services",
    "cik": "0000920148"
  },
  {
    "symbol": "LRCX",
    "name": "Lam Research",
    "sector": "Information Technology",
    "subIndustry": "Semiconductor Materials & Equipment",
    "cik": "0000707549"
  },
  {
    "symbol": "LVS",
    "name": "Las Vegas Sands",
    "sector": "Consumer Discretionary",
    "subIndustry": "Casinos & Gaming",
    "cik": "0001300514"
  },
  {
    "symbol": "LDOS",
    "name": "Leidos",
    "sector": "Industrials",
    "subIndustry": "Diversified Support Services",
    "cik": "0001336920"
  },
  {
    "symbol": "LEN",
    "name": "Lennar",
    "sector": "Consumer Discretionary",
    "subIndustry": "Homebuilding",
    "cik": "0000920760"
  },
  {
    "symbol": "LII",
    "name": "Lennox International",
    "sector": "Industrials",
    "subIndustry": "Building Products",
    "cik": "0001069202"
  },
  {
    "symbol": "LLY",
    "name": "Lilly (Eli)",
    "sector": "Health Care",
    "subIndustry": "Pharmaceuticals",
    "cik": "0000059478"
  },
  {
    "symbol": "LIN",
    "name": "Linde plc",
    "sector": "Materials",
    "subIndustry": "Industrial Gases",
    "cik": "0001707925"
  },
  {
    "symbol": "LYV",
    "name": "Live Nation Entertainment",
    "sector": "Communication Services",
    "subIndustry": "Movies & Entertainment",
    "cik": "0001335258"
  },
  {
    "symbol": "LMT",
    "name": "Lockheed Martin",
    "sector": "Industrials",
    "subIndustry": "Aerospace & Defense",
    "cik": "0000936468"
  },
  {
    "symbol": "L",
    "name": "Loews Corporation",
    "sector": "Financials",
    "subIndustry": "Multi-line Insurance",
    "cik": "0000060086"
  },
  {
    "symbol": "LOW",
    "name": "Lowe's",
    "sector": "Consumer Discretionary",
    "subIndustry": "Home Improvement Retail",
    "cik": "0000060667"
  },
  {
    "symbol": "LULU",
    "name": "Lululemon Athletica",
    "sector": "Consumer Discretionary",
    "subIndustry": "Apparel, Accessories & Luxury Goods",
    "cik": "0001397187"
  },
  {
    "symbol": "LITE",
    "name": "Lumentum",
    "sector": "Information Technology",
    "subIndustry": "Communications Equipment",
    "cik": "0001633978"
  },
  {
    "symbol": "LYB",
    "name": "LyondellBasell",
    "sector": "Materials",
    "subIndustry": "Specialty Chemicals",
    "cik": "0001489393"
  },
  {
    "symbol": "MTB",
    "name": "M&T Bank",
    "sector": "Financials",
    "subIndustry": "Regional Banks",
    "cik": "0000036270"
  },
  {
    "symbol": "MPC",
    "name": "Marathon Petroleum",
    "sector": "Energy",
    "subIndustry": "Oil & Gas Refining & Marketing",
    "cik": "0001510295"
  },
  {
    "symbol": "MAR",
    "name": "Marriott International",
    "sector": "Consumer Discretionary",
    "subIndustry": "Hotels, Resorts & Cruise Lines",
    "cik": "0001048286"
  },
  {
    "symbol": "MRSH",
    "name": "Marsh McLennan",
    "sector": "Financials",
    "subIndustry": "Insurance Brokers",
    "cik": "0000062709"
  },
  {
    "symbol": "MLM",
    "name": "Martin Marietta Materials",
    "sector": "Materials",
    "subIndustry": "Construction Materials",
    "cik": "0000916076"
  },
  {
    "symbol": "MRVL",
    "name": "Marvell Technology",
    "sector": "Information Technology",
    "subIndustry": "Semiconductors",
    "cik": "0001835632"
  },
  {
    "symbol": "MAS",
    "name": "Masco",
    "sector": "Industrials",
    "subIndustry": "Building Products",
    "cik": "0000062996"
  },
  {
    "symbol": "MA",
    "name": "Mastercard",
    "sector": "Financials",
    "subIndustry": "Transaction & Payment Processing Services",
    "cik": "0001141391"
  },
  {
    "symbol": "MKC",
    "name": "McCormick & Company",
    "sector": "Consumer Staples",
    "subIndustry": "Packaged Foods & Meats",
    "cik": "0000063754"
  },
  {
    "symbol": "MCD",
    "name": "McDonald's",
    "sector": "Consumer Discretionary",
    "subIndustry": "Restaurants",
    "cik": "0000063908"
  },
  {
    "symbol": "MCK",
    "name": "McKesson",
    "sector": "Health Care",
    "subIndustry": "Health Care Distributors",
    "cik": "0000927653"
  },
  {
    "symbol": "MDT",
    "name": "Medtronic",
    "sector": "Health Care",
    "subIndustry": "Health Care Equipment",
    "cik": "0001613103"
  },
  {
    "symbol": "MRK",
    "name": "Merck & Co.",
    "sector": "Health Care",
    "subIndustry": "Pharmaceuticals",
    "cik": "0000310158"
  },
  {
    "symbol": "META",
    "name": "Meta Platforms",
    "sector": "Communication Services",
    "subIndustry": "Interactive Media & Services",
    "cik": "0001326801"
  },
  {
    "symbol": "MET",
    "name": "MetLife",
    "sector": "Financials",
    "subIndustry": "Life & Health Insurance",
    "cik": "0001099219"
  },
  {
    "symbol": "MTD",
    "name": "Mettler Toledo",
    "sector": "Health Care",
    "subIndustry": "Life Sciences Tools & Services",
    "cik": "0001037646"
  },
  {
    "symbol": "MGM",
    "name": "MGM Resorts",
    "sector": "Consumer Discretionary",
    "subIndustry": "Casinos & Gaming",
    "cik": "0000789570"
  },
  {
    "symbol": "MCHP",
    "name": "Microchip Technology",
    "sector": "Information Technology",
    "subIndustry": "Semiconductors",
    "cik": "0000827054"
  },
  {
    "symbol": "MU",
    "name": "Micron Technology",
    "sector": "Information Technology",
    "subIndustry": "Semiconductors",
    "cik": "0000723125"
  },
  {
    "symbol": "MSFT",
    "name": "Microsoft",
    "sector": "Information Technology",
    "subIndustry": "Systems Software",
    "cik": "0000789019"
  },
  {
    "symbol": "MAA",
    "name": "Mid-America Apartment Communities",
    "sector": "Real Estate",
    "subIndustry": "Multi-Family Residential REITs",
    "cik": "0000912595"
  },
  {
    "symbol": "MRNA",
    "name": "Moderna",
    "sector": "Health Care",
    "subIndustry": "Biotechnology",
    "cik": "0001682852"
  },
  {
    "symbol": "MDLZ",
    "name": "Mondelez International",
    "sector": "Consumer Staples",
    "subIndustry": "Packaged Foods & Meats",
    "cik": "0001103982"
  },
  {
    "symbol": "MPWR",
    "name": "Monolithic Power Systems",
    "sector": "Information Technology",
    "subIndustry": "Semiconductors",
    "cik": "0001280452"
  },
  {
    "symbol": "MNST",
    "name": "Monster Beverage",
    "sector": "Consumer Staples",
    "subIndustry": "Soft Drinks & Non-alcoholic Beverages",
    "cik": "0000865752"
  },
  {
    "symbol": "MCO",
    "name": "Moody's Corporation",
    "sector": "Financials",
    "subIndustry": "Financial Exchanges & Data",
    "cik": "0001059556"
  },
  {
    "symbol": "MS",
    "name": "Morgan Stanley",
    "sector": "Financials",
    "subIndustry": "Investment Banking & Brokerage",
    "cik": "0000895421"
  },
  {
    "symbol": "MOS",
    "name": "Mosaic Company (The)",
    "sector": "Materials",
    "subIndustry": "Fertilizers & Agricultural Chemicals",
    "cik": "0001285785"
  },
  {
    "symbol": "MSI",
    "name": "Motorola Solutions",
    "sector": "Information Technology",
    "subIndustry": "Communications Equipment",
    "cik": "0000068505"
  },
  {
    "symbol": "MSCI",
    "name": "MSCI",
    "sector": "Financials",
    "subIndustry": "Financial Exchanges & Data",
    "cik": "0001408198"
  },
  {
    "symbol": "NDAQ",
    "name": "Nasdaq, Inc.",
    "sector": "Financials",
    "subIndustry": "Financial Exchanges & Data",
    "cik": "0001120193"
  },
  {
    "symbol": "NTAP",
    "name": "NetApp",
    "sector": "Information Technology",
    "subIndustry": "Technology Hardware, Storage & Peripherals",
    "cik": "0001002047"
  },
  {
    "symbol": "NFLX",
    "name": "Netflix",
    "sector": "Communication Services",
    "subIndustry": "Movies & Entertainment",
    "cik": "0001065280"
  },
  {
    "symbol": "NEM",
    "name": "Newmont",
    "sector": "Materials",
    "subIndustry": "Gold",
    "cik": "0001164727"
  },
  {
    "symbol": "NWSA",
    "name": "News Corp (Class A)",
    "sector": "Communication Services",
    "subIndustry": "Publishing",
    "cik": "0001564708"
  },
  {
    "symbol": "NWS",
    "name": "News Corp (Class B)",
    "sector": "Communication Services",
    "subIndustry": "Publishing",
    "cik": "0001564708"
  },
  {
    "symbol": "NEE",
    "name": "NextEra Energy",
    "sector": "Utilities",
    "subIndustry": "Multi-Utilities",
    "cik": "0000753308"
  },
  {
    "symbol": "NKE",
    "name": "Nike, Inc.",
    "sector": "Consumer Discretionary",
    "subIndustry": "Apparel, Accessories & Luxury Goods",
    "cik": "0000320187"
  },
  {
    "symbol": "NI",
    "name": "NiSource",
    "sector": "Utilities",
    "subIndustry": "Multi-Utilities",
    "cik": "0001111711"
  },
  {
    "symbol": "NDSN",
    "name": "Nordson Corporation",
    "sector": "Industrials",
    "subIndustry": "Industrial Machinery & Supplies & Components",
    "cik": "0000072331"
  },
  {
    "symbol": "NSC",
    "name": "Norfolk Southern",
    "sector": "Industrials",
    "subIndustry": "Rail Transportation",
    "cik": "0000702165"
  },
  {
    "symbol": "NTRS",
    "name": "Northern Trust",
    "sector": "Financials",
    "subIndustry": "Asset Management & Custody Banks",
    "cik": "0000073124"
  },
  {
    "symbol": "NOC",
    "name": "Northrop Grumman",
    "sector": "Industrials",
    "subIndustry": "Aerospace & Defense",
    "cik": "0001133421"
  },
  {
    "symbol": "NCLH",
    "name": "Norwegian Cruise Line Holdings",
    "sector": "Consumer Discretionary",
    "subIndustry": "Hotels, Resorts & Cruise Lines",
    "cik": "0001513761"
  },
  {
    "symbol": "NRG",
    "name": "NRG Energy",
    "sector": "Utilities",
    "subIndustry": "Independent Power Producers & Energy Traders",
    "cik": "0001013871"
  },
  {
    "symbol": "NUE",
    "name": "Nucor",
    "sector": "Materials",
    "subIndustry": "Steel",
    "cik": "0000073309"
  },
  {
    "symbol": "NVDA",
    "name": "Nvidia",
    "sector": "Information Technology",
    "subIndustry": "Semiconductors",
    "cik": "0001045810"
  },
  {
    "symbol": "NVR",
    "name": "NVR, Inc.",
    "sector": "Consumer Discretionary",
    "subIndustry": "Homebuilding",
    "cik": "0000906163"
  },
  {
    "symbol": "NXPI",
    "name": "NXP Semiconductors",
    "sector": "Information Technology",
    "subIndustry": "Semiconductors",
    "cik": "0001413447"
  },
  {
    "symbol": "ORLY",
    "name": "O'Reilly Automotive",
    "sector": "Consumer Discretionary",
    "subIndustry": "Automotive Retail",
    "cik": "0000898173"
  },
  {
    "symbol": "OXY",
    "name": "Occidental Petroleum",
    "sector": "Energy",
    "subIndustry": "Oil & Gas Exploration & Production",
    "cik": "0000797468"
  },
  {
    "symbol": "ODFL",
    "name": "Old Dominion",
    "sector": "Industrials",
    "subIndustry": "Cargo Ground Transportation",
    "cik": "0000878927"
  },
  {
    "symbol": "OMC",
    "name": "Omnicom Group",
    "sector": "Communication Services",
    "subIndustry": "Advertising",
    "cik": "0000029989"
  },
  {
    "symbol": "ON",
    "name": "ON Semiconductor",
    "sector": "Information Technology",
    "subIndustry": "Semiconductors",
    "cik": "0001097864"
  },
  {
    "symbol": "OKE",
    "name": "Oneok",
    "sector": "Energy",
    "subIndustry": "Oil & Gas Storage & Transportation",
    "cik": "0001039684"
  },
  {
    "symbol": "ORCL",
    "name": "Oracle Corporation",
    "sector": "Information Technology",
    "subIndustry": "Application Software",
    "cik": "0001341439"
  },
  {
    "symbol": "OTIS",
    "name": "Otis Worldwide",
    "sector": "Industrials",
    "subIndustry": "Industrial Machinery & Supplies & Components",
    "cik": "0001781335"
  },
  {
    "symbol": "PCAR",
    "name": "Paccar",
    "sector": "Industrials",
    "subIndustry": "Construction Machinery & Heavy Transportation Equipment",
    "cik": "0000075362"
  },
  {
    "symbol": "PKG",
    "name": "Packaging Corporation of America",
    "sector": "Materials",
    "subIndustry": "Paper & Plastic Packaging Products & Materials",
    "cik": "0000075677"
  },
  {
    "symbol": "PLTR",
    "name": "Palantir Technologies",
    "sector": "Information Technology",
    "subIndustry": "Application Software",
    "cik": "0001321655"
  },
  {
    "symbol": "PANW",
    "name": "Palo Alto Networks",
    "sector": "Information Technology",
    "subIndustry": "Systems Software",
    "cik": "0001327567"
  },
  {
    "symbol": "PH",
    "name": "Parker Hannifin",
    "sector": "Industrials",
    "subIndustry": "Industrial Machinery & Supplies & Components",
    "cik": "0000076334"
  },
  {
    "symbol": "PAYX",
    "name": "Paychex",
    "sector": "Industrials",
    "subIndustry": "Human Resource & Employment Services",
    "cik": "0000723531"
  },
  {
    "symbol": "PYPL",
    "name": "PayPal",
    "sector": "Financials",
    "subIndustry": "Transaction & Payment Processing Services",
    "cik": "0001633917"
  },
  {
    "symbol": "PNR",
    "name": "Pentair",
    "sector": "Industrials",
    "subIndustry": "Industrial Machinery & Supplies & Components",
    "cik": "0000077360"
  },
  {
    "symbol": "PEP",
    "name": "PepsiCo",
    "sector": "Consumer Staples",
    "subIndustry": "Soft Drinks & Non-alcoholic Beverages",
    "cik": "0000077476"
  },
  {
    "symbol": "PFE",
    "name": "Pfizer",
    "sector": "Health Care",
    "subIndustry": "Pharmaceuticals",
    "cik": "0000078003"
  },
  {
    "symbol": "PCG",
    "name": "PG&E Corporation",
    "sector": "Utilities",
    "subIndustry": "Multi-Utilities",
    "cik": "0001004980"
  },
  {
    "symbol": "PM",
    "name": "Philip Morris International",
    "sector": "Consumer Staples",
    "subIndustry": "Tobacco",
    "cik": "0001413329"
  },
  {
    "symbol": "PSX",
    "name": "Phillips 66",
    "sector": "Energy",
    "subIndustry": "Oil & Gas Refining & Marketing",
    "cik": "0001534701"
  },
  {
    "symbol": "PNW",
    "name": "Pinnacle West Capital",
    "sector": "Utilities",
    "subIndustry": "Multi-Utilities",
    "cik": "0000764622"
  },
  {
    "symbol": "PNC",
    "name": "PNC Financial Services",
    "sector": "Financials",
    "subIndustry": "Diversified Banks",
    "cik": "0000713676"
  },
  {
    "symbol": "PPG",
    "name": "PPG Industries",
    "sector": "Materials",
    "subIndustry": "Specialty Chemicals",
    "cik": "0000079879"
  },
  {
    "symbol": "PPL",
    "name": "PPL Corporation",
    "sector": "Utilities",
    "subIndustry": "Electric Utilities",
    "cik": "0000922224"
  },
  {
    "symbol": "PFG",
    "name": "Principal Financial Group",
    "sector": "Financials",
    "subIndustry": "Life & Health Insurance",
    "cik": "0001126328"
  },
  {
    "symbol": "PG",
    "name": "Procter & Gamble",
    "sector": "Consumer Staples",
    "subIndustry": "Personal Care Products",
    "cik": "0000080424"
  },
  {
    "symbol": "PGR",
    "name": "Progressive Corporation",
    "sector": "Financials",
    "subIndustry": "Property & Casualty Insurance",
    "cik": "0000080661"
  },
  {
    "symbol": "PLD",
    "name": "Prologis",
    "sector": "Real Estate",
    "subIndustry": "Industrial REITs",
    "cik": "0001045609"
  },
  {
    "symbol": "PRU",
    "name": "Prudential Financial",
    "sector": "Financials",
    "subIndustry": "Life & Health Insurance",
    "cik": "0001137774"
  },
  {
    "symbol": "PTC",
    "name": "PTC Inc.",
    "sector": "Information Technology",
    "subIndustry": "Application Software",
    "cik": "0000857005"
  },
  {
    "symbol": "PEG",
    "name": "Public Service Enterprise Group",
    "sector": "Utilities",
    "subIndustry": "Electric Utilities",
    "cik": "0000788784"
  },
  {
    "symbol": "PSA",
    "name": "Public Storage",
    "sector": "Real Estate",
    "subIndustry": "Self-Storage REITs",
    "cik": "0001393311"
  },
  {
    "symbol": "PHM",
    "name": "PulteGroup",
    "sector": "Consumer Discretionary",
    "subIndustry": "Homebuilding",
    "cik": "0000822416"
  },
  {
    "symbol": "Q",
    "name": "Qnity Electronics",
    "sector": "Information Technology",
    "subIndustry": "Semiconductor Materials & Equipment",
    "cik": "0002058873"
  },
  {
    "symbol": "QCOM",
    "name": "Qualcomm",
    "sector": "Information Technology",
    "subIndustry": "Semiconductors",
    "cik": "0000804328"
  },
  {
    "symbol": "PWR",
    "name": "Quanta Services",
    "sector": "Industrials",
    "subIndustry": "Construction & Engineering",
    "cik": "0001050915"
  },
  {
    "symbol": "DGX",
    "name": "Quest Diagnostics",
    "sector": "Health Care",
    "subIndustry": "Health Care Services",
    "cik": "0001022079"
  },
  {
    "symbol": "RL",
    "name": "Ralph Lauren Corporation",
    "sector": "Consumer Discretionary",
    "subIndustry": "Apparel, Accessories & Luxury Goods",
    "cik": "0001037038"
  },
  {
    "symbol": "RJF",
    "name": "Raymond James Financial",
    "sector": "Financials",
    "subIndustry": "Investment Banking & Brokerage",
    "cik": "0000720005"
  },
  {
    "symbol": "RDDT",
    "name": "Reddit",
    "sector": "Communication Services",
    "subIndustry": "Interactive Media & Services",
    "cik": "0001713445"
  },
  {
    "symbol": "O",
    "name": "Realty Income",
    "sector": "Real Estate",
    "subIndustry": "Retail REITs",
    "cik": "0000726728"
  },
  {
    "symbol": "REG",
    "name": "Regency Centers",
    "sector": "Real Estate",
    "subIndustry": "Retail REITs",
    "cik": "0000910606"
  },
  {
    "symbol": "REGN",
    "name": "Regeneron Pharmaceuticals",
    "sector": "Health Care",
    "subIndustry": "Biotechnology",
    "cik": "0000872589"
  },
  {
    "symbol": "RF",
    "name": "Regions Financial Corporation",
    "sector": "Financials",
    "subIndustry": "Regional Banks",
    "cik": "0001281761"
  },
  {
    "symbol": "RSG",
    "name": "Republic Services",
    "sector": "Industrials",
    "subIndustry": "Environmental & Facilities Services",
    "cik": "0001060391"
  },
  {
    "symbol": "RMD",
    "name": "ResMed",
    "sector": "Health Care",
    "subIndustry": "Health Care Equipment",
    "cik": "0000943819"
  },
  {
    "symbol": "RVTY",
    "name": "Revvity",
    "sector": "Health Care",
    "subIndustry": "Health Care Equipment",
    "cik": "0000031791"
  },
  {
    "symbol": "HOOD",
    "name": "Robinhood Markets",
    "sector": "Financials",
    "subIndustry": "Investment Banking & Brokerage",
    "cik": "0001783879"
  },
  {
    "symbol": "ROK",
    "name": "Rockwell Automation",
    "sector": "Industrials",
    "subIndustry": "Electrical Components & Equipment",
    "cik": "0001024478"
  },
  {
    "symbol": "ROL",
    "name": "Rollins, Inc.",
    "sector": "Industrials",
    "subIndustry": "Environmental & Facilities Services",
    "cik": "0000084839"
  },
  {
    "symbol": "ROP",
    "name": "Roper Technologies",
    "sector": "Information Technology",
    "subIndustry": "Electronic Equipment & Instruments",
    "cik": "0000882835"
  },
  {
    "symbol": "ROST",
    "name": "Ross Stores",
    "sector": "Consumer Discretionary",
    "subIndustry": "Apparel Retail",
    "cik": "0000745732"
  },
  {
    "symbol": "RCL",
    "name": "Royal Caribbean Group",
    "sector": "Consumer Discretionary",
    "subIndustry": "Hotels, Resorts & Cruise Lines",
    "cik": "0000884887"
  },
  {
    "symbol": "RTX",
    "name": "RTX Corporation",
    "sector": "Industrials",
    "subIndustry": "Aerospace & Defense",
    "cik": "0000101829"
  },
  {
    "symbol": "SPGI",
    "name": "S&P Global",
    "sector": "Financials",
    "subIndustry": "Financial Exchanges & Data",
    "cik": "0000064040"
  },
  {
    "symbol": "CRM",
    "name": "Salesforce",
    "sector": "Information Technology",
    "subIndustry": "Application Software",
    "cik": "0001108524"
  },
  {
    "symbol": "SNDK",
    "name": "Sandisk",
    "sector": "Information Technology",
    "subIndustry": "Technology Hardware, Storage & Peripherals",
    "cik": "0002023554"
  },
  {
    "symbol": "SBAC",
    "name": "SBA Communications",
    "sector": "Real Estate",
    "subIndustry": "Telecom Tower REITs",
    "cik": "0001034054"
  },
  {
    "symbol": "SLB",
    "name": "Schlumberger",
    "sector": "Energy",
    "subIndustry": "Oil & Gas Equipment & Services",
    "cik": "0000087347"
  },
  {
    "symbol": "STX",
    "name": "Seagate Technology",
    "sector": "Information Technology",
    "subIndustry": "Technology Hardware, Storage & Peripherals",
    "cik": "0001137789"
  },
  {
    "symbol": "SRE",
    "name": "Sempra",
    "sector": "Utilities",
    "subIndustry": "Multi-Utilities",
    "cik": "0001032208"
  },
  {
    "symbol": "NOW",
    "name": "ServiceNow",
    "sector": "Information Technology",
    "subIndustry": "Systems Software",
    "cik": "0001373715"
  },
  {
    "symbol": "SHW",
    "name": "Sherwin-Williams",
    "sector": "Materials",
    "subIndustry": "Specialty Chemicals",
    "cik": "0000089800"
  },
  {
    "symbol": "SPG",
    "name": "Simon Property Group",
    "sector": "Real Estate",
    "subIndustry": "Retail REITs",
    "cik": "0001063761"
  },
  {
    "symbol": "SKYD",
    "name": "Skydance",
    "sector": "Communication Services",
    "subIndustry": "Movies & Entertainment",
    "cik": "0002041610"
  },
  {
    "symbol": "SWKS",
    "name": "Skyworks Solutions",
    "sector": "Information Technology",
    "subIndustry": "Semiconductors",
    "cik": "0000004127"
  },
  {
    "symbol": "SJM",
    "name": "J.M. Smucker Company (The)",
    "sector": "Consumer Staples",
    "subIndustry": "Packaged Foods & Meats",
    "cik": "0000091419"
  },
  {
    "symbol": "SW",
    "name": "Smurfit Westrock",
    "sector": "Materials",
    "subIndustry": "Paper & Plastic Packaging Products & Materials",
    "cik": "0002005951"
  },
  {
    "symbol": "SNA",
    "name": "Snap-on",
    "sector": "Industrials",
    "subIndustry": "Industrial Machinery & Supplies & Components",
    "cik": "0000091440"
  },
  {
    "symbol": "SOLV",
    "name": "Solventum",
    "sector": "Health Care",
    "subIndustry": "Health Care Technology",
    "cik": "0001964738"
  },
  {
    "symbol": "SO",
    "name": "Southern Company",
    "sector": "Utilities",
    "subIndustry": "Electric Utilities",
    "cik": "0000092122"
  },
  {
    "symbol": "LUV",
    "name": "Southwest Airlines",
    "sector": "Industrials",
    "subIndustry": "Passenger Airlines",
    "cik": "0000092380"
  },
  {
    "symbol": "SWK",
    "name": "Stanley Black & Decker",
    "sector": "Industrials",
    "subIndustry": "Industrial Machinery & Supplies & Components",
    "cik": "0000093556"
  },
  {
    "symbol": "SBUX",
    "name": "Starbucks",
    "sector": "Consumer Discretionary",
    "subIndustry": "Restaurants",
    "cik": "0000829224"
  },
  {
    "symbol": "STT",
    "name": "State Street Corporation",
    "sector": "Financials",
    "subIndustry": "Asset Management & Custody Banks",
    "cik": "0000093751"
  },
  {
    "symbol": "STLD",
    "name": "Steel Dynamics",
    "sector": "Materials",
    "subIndustry": "Steel",
    "cik": "0001022671"
  },
  {
    "symbol": "STE",
    "name": "Steris",
    "sector": "Health Care",
    "subIndustry": "Health Care Equipment",
    "cik": "0001757898"
  },
  {
    "symbol": "SYK",
    "name": "Stryker Corporation",
    "sector": "Health Care",
    "subIndustry": "Health Care Equipment",
    "cik": "0000310764"
  },
  {
    "symbol": "SMCI",
    "name": "Supermicro",
    "sector": "Information Technology",
    "subIndustry": "Technology Hardware, Storage & Peripherals",
    "cik": "0001375365"
  },
  {
    "symbol": "SYF",
    "name": "Synchrony Financial",
    "sector": "Financials",
    "subIndustry": "Consumer Finance",
    "cik": "0001601712"
  },
  {
    "symbol": "SNPS",
    "name": "Synopsys",
    "sector": "Information Technology",
    "subIndustry": "Application Software",
    "cik": "0000883241"
  },
  {
    "symbol": "SYY",
    "name": "Sysco",
    "sector": "Consumer Staples",
    "subIndustry": "Food Distributors",
    "cik": "0000096021"
  },
  {
    "symbol": "TMUS",
    "name": "T-Mobile US",
    "sector": "Communication Services",
    "subIndustry": "Wireless Telecommunication Services",
    "cik": "0001283699"
  },
  {
    "symbol": "TROW",
    "name": "T. Rowe Price",
    "sector": "Financials",
    "subIndustry": "Asset Management & Custody Banks",
    "cik": "0001113169"
  },
  {
    "symbol": "TTWO",
    "name": "Take-Two Interactive",
    "sector": "Communication Services",
    "subIndustry": "Interactive Home Entertainment",
    "cik": "0000946581"
  },
  {
    "symbol": "TPR",
    "name": "Tapestry, Inc.",
    "sector": "Consumer Discretionary",
    "subIndustry": "Apparel, Accessories & Luxury Goods",
    "cik": "0001116132"
  },
  {
    "symbol": "TRGP",
    "name": "Targa Resources",
    "sector": "Energy",
    "subIndustry": "Oil & Gas Storage & Transportation",
    "cik": "0001389170"
  },
  {
    "symbol": "TGT",
    "name": "Target Corporation",
    "sector": "Consumer Staples",
    "subIndustry": "Consumer Staples Merchandise Retail",
    "cik": "0000027419"
  },
  {
    "symbol": "TEL",
    "name": "TE Connectivity",
    "sector": "Information Technology",
    "subIndustry": "Electronic Manufacturing Services",
    "cik": "0001385157"
  },
  {
    "symbol": "TDY",
    "name": "Teledyne Technologies",
    "sector": "Information Technology",
    "subIndustry": "Electronic Equipment & Instruments",
    "cik": "0001094285"
  },
  {
    "symbol": "TER",
    "name": "Teradyne",
    "sector": "Information Technology",
    "subIndustry": "Semiconductor Materials & Equipment",
    "cik": "0000097210"
  },
  {
    "symbol": "TSLA",
    "name": "Tesla, Inc.",
    "sector": "Consumer Discretionary",
    "subIndustry": "Automobile Manufacturers",
    "cik": "0001318605"
  },
  {
    "symbol": "TXN",
    "name": "Texas Instruments",
    "sector": "Information Technology",
    "subIndustry": "Semiconductors",
    "cik": "0000097476"
  },
  {
    "symbol": "TPL",
    "name": "Texas Pacific Land Corporation",
    "sector": "Energy",
    "subIndustry": "Oil & Gas Exploration & Production",
    "cik": "0001811074"
  },
  {
    "symbol": "TXT",
    "name": "Textron",
    "sector": "Industrials",
    "subIndustry": "Aerospace & Defense",
    "cik": "0000217346"
  },
  {
    "symbol": "TMO",
    "name": "Thermo Fisher Scientific",
    "sector": "Health Care",
    "subIndustry": "Life Sciences Tools & Services",
    "cik": "0000097745"
  },
  {
    "symbol": "TJX",
    "name": "TJX Companies",
    "sector": "Consumer Discretionary",
    "subIndustry": "Apparel Retail",
    "cik": "0000109198"
  },
  {
    "symbol": "TKO",
    "name": "TKO Group Holdings",
    "sector": "Communication Services",
    "subIndustry": "Movies & Entertainment",
    "cik": "0001973266"
  },
  {
    "symbol": "TSCO",
    "name": "Tractor Supply",
    "sector": "Consumer Discretionary",
    "subIndustry": "Other Specialty Retail",
    "cik": "0000916365"
  },
  {
    "symbol": "TT",
    "name": "Trane Technologies",
    "sector": "Industrials",
    "subIndustry": "Building Products",
    "cik": "0001466258"
  },
  {
    "symbol": "TDG",
    "name": "TransDigm Group",
    "sector": "Industrials",
    "subIndustry": "Aerospace & Defense",
    "cik": "0001260221"
  },
  {
    "symbol": "TRV",
    "name": "Travelers Companies (The)",
    "sector": "Financials",
    "subIndustry": "Property & Casualty Insurance",
    "cik": "0000086312"
  },
  {
    "symbol": "TRMB",
    "name": "Trimble Inc.",
    "sector": "Information Technology",
    "subIndustry": "Application Software",
    "cik": "0000864749"
  },
  {
    "symbol": "TFC",
    "name": "Truist Financial",
    "sector": "Financials",
    "subIndustry": "Diversified Banks",
    "cik": "0000092230"
  },
  {
    "symbol": "TWLO",
    "name": "Twilio",
    "sector": "Information Technology",
    "subIndustry": "Systems Software",
    "cik": "0001447669"
  },
  {
    "symbol": "TYL",
    "name": "Tyler Technologies",
    "sector": "Information Technology",
    "subIndustry": "Application Software",
    "cik": "0000860731"
  },
  {
    "symbol": "TSN",
    "name": "Tyson Foods",
    "sector": "Consumer Staples",
    "subIndustry": "Packaged Foods & Meats",
    "cik": "0000100493"
  },
  {
    "symbol": "USB",
    "name": "U.S. Bancorp",
    "sector": "Financials",
    "subIndustry": "Diversified Banks",
    "cik": "0000036104"
  },
  {
    "symbol": "UBER",
    "name": "Uber",
    "sector": "Industrials",
    "subIndustry": "Passenger Ground Transportation",
    "cik": "0001543151"
  },
  {
    "symbol": "UDR",
    "name": "UDR, Inc.",
    "sector": "Real Estate",
    "subIndustry": "Multi-Family Residential REITs",
    "cik": "0000074208"
  },
  {
    "symbol": "ULTA",
    "name": "Ulta Beauty",
    "sector": "Consumer Discretionary",
    "subIndustry": "Other Specialty Retail",
    "cik": "0001403568"
  },
  {
    "symbol": "UNP",
    "name": "Union Pacific Corporation",
    "sector": "Industrials",
    "subIndustry": "Rail Transportation",
    "cik": "0000100885"
  },
  {
    "symbol": "UAL",
    "name": "United Airlines Holdings",
    "sector": "Industrials",
    "subIndustry": "Passenger Airlines",
    "cik": "0000100517"
  },
  {
    "symbol": "UPS",
    "name": "United Parcel Service",
    "sector": "Industrials",
    "subIndustry": "Air Freight & Logistics",
    "cik": "0001090727"
  },
  {
    "symbol": "URI",
    "name": "United Rentals",
    "sector": "Industrials",
    "subIndustry": "Trading Companies & Distributors",
    "cik": "0001067701"
  },
  {
    "symbol": "UNH",
    "name": "UnitedHealth Group",
    "sector": "Health Care",
    "subIndustry": "Managed Health Care",
    "cik": "0000731766"
  },
  {
    "symbol": "UHS",
    "name": "Universal Health Services",
    "sector": "Health Care",
    "subIndustry": "Health Care Facilities",
    "cik": "0000352915"
  },
  {
    "symbol": "VLO",
    "name": "Valero Energy",
    "sector": "Energy",
    "subIndustry": "Oil & Gas Refining & Marketing",
    "cik": "0001035002"
  },
  {
    "symbol": "VEEV",
    "name": "Veeva Systems",
    "sector": "Health Care",
    "subIndustry": "Health Care Technology",
    "cik": "0001393052"
  },
  {
    "symbol": "VTR",
    "name": "Ventas",
    "sector": "Real Estate",
    "subIndustry": "Health Care REITs",
    "cik": "0000740260"
  },
  {
    "symbol": "VLTO",
    "name": "Veralto",
    "sector": "Industrials",
    "subIndustry": "Environmental & Facilities Services",
    "cik": "0001967680"
  },
  {
    "symbol": "VRSN",
    "name": "Verisign",
    "sector": "Information Technology",
    "subIndustry": "Internet Services & Infrastructure",
    "cik": "0001014473"
  },
  {
    "symbol": "VRSK",
    "name": "Verisk Analytics",
    "sector": "Industrials",
    "subIndustry": "Research & Consulting Services",
    "cik": "0001442145"
  },
  {
    "symbol": "VZ",
    "name": "Verizon",
    "sector": "Communication Services",
    "subIndustry": "Integrated Telecommunication Services",
    "cik": "0000732712"
  },
  {
    "symbol": "VRTX",
    "name": "Vertex Pharmaceuticals",
    "sector": "Health Care",
    "subIndustry": "Biotechnology",
    "cik": "0000875320"
  },
  {
    "symbol": "VRT",
    "name": "Vertiv",
    "sector": "Industrials",
    "subIndustry": "Electrical Components & Equipment",
    "cik": "0001674101"
  },
  {
    "symbol": "VTRS",
    "name": "Viatris",
    "sector": "Health Care",
    "subIndustry": "Pharmaceuticals",
    "cik": "0001792044"
  },
  {
    "symbol": "VICI",
    "name": "Vici Properties",
    "sector": "Real Estate",
    "subIndustry": "Hotel & Resort REITs",
    "cik": "0001705696"
  },
  {
    "symbol": "V",
    "name": "Visa Inc.",
    "sector": "Financials",
    "subIndustry": "Transaction & Payment Processing Services",
    "cik": "0001403161"
  },
  {
    "symbol": "VST",
    "name": "Vistra Corp.",
    "sector": "Utilities",
    "subIndustry": "Electric Utilities",
    "cik": "0001692819"
  },
  {
    "symbol": "VMRK",
    "name": "Vivmark Residential",
    "sector": "Real Estate",
    "subIndustry": "Multi-Family Residential REITs",
    "cik": "0000906107"
  },
  {
    "symbol": "VMC",
    "name": "Vulcan Materials Company",
    "sector": "Materials",
    "subIndustry": "Construction Materials",
    "cik": "0001396009"
  },
  {
    "symbol": "VYLR",
    "name": "Vylor",
    "sector": "Consumer Staples",
    "subIndustry": "Agricultural Products & Services",
    "cik": "0002128626"
  },
  {
    "symbol": "WRB",
    "name": "W. R. Berkley Corporation",
    "sector": "Financials",
    "subIndustry": "Property & Casualty Insurance",
    "cik": "0000011544"
  },
  {
    "symbol": "GWW",
    "name": "W. W. Grainger",
    "sector": "Industrials",
    "subIndustry": "Industrial Machinery & Supplies & Components",
    "cik": "0000277135"
  },
  {
    "symbol": "WAB",
    "name": "Wabtec",
    "sector": "Industrials",
    "subIndustry": "Construction Machinery & Heavy Transportation Equipment",
    "cik": "0000943452"
  },
  {
    "symbol": "WMT",
    "name": "Walmart",
    "sector": "Consumer Staples",
    "subIndustry": "Consumer Staples Merchandise Retail",
    "cik": "0000104169"
  },
  {
    "symbol": "DIS",
    "name": "Walt Disney Company (The)",
    "sector": "Communication Services",
    "subIndustry": "Movies & Entertainment",
    "cik": "0001744489"
  },
  {
    "symbol": "WM",
    "name": "Waste Management",
    "sector": "Industrials",
    "subIndustry": "Environmental & Facilities Services",
    "cik": "0000823768"
  },
  {
    "symbol": "WAT",
    "name": "Waters Corporation",
    "sector": "Health Care",
    "subIndustry": "Life Sciences Tools & Services",
    "cik": "0001000697"
  },
  {
    "symbol": "WEC",
    "name": "WEC Energy Group",
    "sector": "Utilities",
    "subIndustry": "Electric Utilities",
    "cik": "0000783325"
  },
  {
    "symbol": "WFC",
    "name": "Wells Fargo",
    "sector": "Financials",
    "subIndustry": "Diversified Banks",
    "cik": "0000072971"
  },
  {
    "symbol": "WELL",
    "name": "Welltower",
    "sector": "Real Estate",
    "subIndustry": "Health Care REITs",
    "cik": "0000766704"
  },
  {
    "symbol": "WST",
    "name": "West Pharmaceutical Services",
    "sector": "Health Care",
    "subIndustry": "Health Care Supplies",
    "cik": "0000105770"
  },
  {
    "symbol": "WDC",
    "name": "Western Digital",
    "sector": "Information Technology",
    "subIndustry": "Technology Hardware, Storage & Peripherals",
    "cik": "0000106040"
  },
  {
    "symbol": "WY",
    "name": "Weyerhaeuser",
    "sector": "Real Estate",
    "subIndustry": "Timber REITs",
    "cik": "0000106535"
  },
  {
    "symbol": "WSM",
    "name": "Williams-Sonoma, Inc.",
    "sector": "Consumer Discretionary",
    "subIndustry": "Homefurnishing Retail",
    "cik": "0000719955"
  },
  {
    "symbol": "WMB",
    "name": "Williams Companies",
    "sector": "Energy",
    "subIndustry": "Oil & Gas Storage & Transportation",
    "cik": "0000107263"
  },
  {
    "symbol": "WTW",
    "name": "Willis Towers Watson",
    "sector": "Financials",
    "subIndustry": "Insurance Brokers",
    "cik": "0001140536"
  },
  {
    "symbol": "WDAY",
    "name": "Workday, Inc.",
    "sector": "Information Technology",
    "subIndustry": "Application Software",
    "cik": "0001327811"
  },
  {
    "symbol": "WYNN",
    "name": "Wynn Resorts",
    "sector": "Consumer Discretionary",
    "subIndustry": "Casinos & Gaming",
    "cik": "0001174922"
  },
  {
    "symbol": "XEL",
    "name": "Xcel Energy",
    "sector": "Utilities",
    "subIndustry": "Multi-Utilities",
    "cik": "0000072903"
  },
  {
    "symbol": "XYL",
    "name": "Xylem Inc.",
    "sector": "Industrials",
    "subIndustry": "Industrial Machinery & Supplies & Components",
    "cik": "0001524472"
  },
  {
    "symbol": "YUM",
    "name": "Yum! Brands",
    "sector": "Consumer Discretionary",
    "subIndustry": "Restaurants",
    "cik": "0001041061"
  },
  {
    "symbol": "ZBRA",
    "name": "Zebra Technologies",
    "sector": "Information Technology",
    "subIndustry": "Electronic Equipment & Instruments",
    "cik": "0000877212"
  },
  {
    "symbol": "ZBH",
    "name": "Zimmer Biomet",
    "sector": "Health Care",
    "subIndustry": "Health Care Equipment",
    "cik": "0001136869"
  },
  {
    "symbol": "ZTS",
    "name": "Zoetis",
    "sector": "Health Care",
    "subIndustry": "Pharmaceuticals",
    "cik": "0001555280"
  }
];

export const SP500_TOP_50: string[] = [
  'AAPL', 'MSFT', 'NVDA', 'AMZN', 'GOOGL', 'META', 'TSLA', 'BRK-B', 'AVGO', 'JPM',
  'LLY', 'V', 'UNH', 'XOM', 'MA', 'COST', 'PG', 'HD', 'JNJ', 'WMT',
  'ABBV', 'MRK', 'NFLX', 'CRM', 'BAC', 'CVX', 'ORCL', 'KO', 'AMD', 'ADBE',
  'PEP', 'LIN', 'TMO', 'WFC', 'CSCO', 'MCD', 'ACN', 'GE', 'ABT', 'DIS',
  'PM', 'INTU', 'QCOM', 'CAT', 'TXN', 'VZ', 'AMAT', 'DHR', 'PFE', 'NOW'
];

export function getTickersBySector(sector: string): string[] {
  if (sector === 'All Sectors') {
    return SP500_UNIVERSE.map((c) => c.symbol);
  }
  return SP500_UNIVERSE.filter((c) => c.sector === sector).map((c) => c.symbol);
}
