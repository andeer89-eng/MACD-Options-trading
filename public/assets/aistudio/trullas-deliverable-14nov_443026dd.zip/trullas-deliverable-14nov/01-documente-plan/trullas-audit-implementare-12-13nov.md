# Audit: ce s-a implementat din Master Plan v3 în build-ul live (export 12 nov, 13:53)

Verificat direct în cod (211 fișiere, extras izolat), nu doar căutat după nume. Pentru fiecare linie de mai jos am citit fișierul, nu doar grep pe titlu.

## Verdict într-un paragraf

AI Studio a portat fidel **conceptele și motorul** din planul meu (Regime Score, `Levels`, `canTrade()` cu cele 10 verificări, motorul de ieșiri shadow) într-un modul nou, bine scris, cu teste care chiar trec. Dar le-a adăugat ca **tab nou, izolat** ("Today"), nu le-a folosit pentru a *înlocui* logica veche din bot-urile reale. Rezultatul: ai acum o machetă corectă din punct de vedere al regulilor, dar botul care chiar deschide poziții (`automatedPortfolio.ts`, `optionsAutomatedPortfolio.ts`) nu știe de `canTrade()` și are propriile reguli, vechi. Plus: platforma reală e **Firebase/Firestore**, nu Supabase/Postgres cum presupunea planul meu (bazat pe documentul tău de schemă) — asta schimbă ce înseamnă "implementat" pentru tot ce am scris în SQL.

---

## 1. Chiar implementat și funcțional (verificat)

| Item din plan | Fișier | Cum am verificat |
|---|---|---|
| `canTrade()` — 10 verificări, ordinea exactă | `src/utils/masterPlanCore.ts:415-568` | citit cod linie cu linie; rulat `masterPlanCore.test.ts` → **4/4 teste trec** |
| Regime Score, 4 benzi, politici | `masterPlanCore.ts:26-74` | valorile (0-30/30-60/60-85/85-100, multiplicatori 0/0,5/1,0/0,75) sunt identice cu planul |
| `Levels` (Anexa B) | `masterPlanCore.ts:209-339` | câmpuri identice: `entryZone`, `stop.basis`, `stopTooWide`, `invalidation`, `markers` |
| Capital + risc reglabile, fără constante hardcodate | `masterPlanCore.ts:80-158` | comentariu explicit „No hardcoded EQUITY0 = 2000!"; citește din Settings |
| Export/Import JSON backup (cele 6 chei) | `masterPlanCore.ts:163-203` | funcțiile există și sunt complete |
| PF ascuns sub n<10 (bug-ul original) | `tradeJournal.ts:330-339`, `TradeJournalView.tsx:492-496` | comentariu „anti PF 99x bug" — **chiar fixat, aici** |
| Watchlist persistată real (nu doar localStorage) | `dailyWatchlistStore.ts:235` | `await setDoc(doc(db,'users',uid,'watchlistItems',...))` — scriere reală în Firestore |
| Reguli de securitate per-utilizator (echivalent RLS) | `firestore.rules` | isolare pe `request.auth.uid`, validare pe câmpuri, `allow read,write: if false` implicit — bine făcut |
| Motor de ieșiri shadow (port din JS-ul meu) | `trullasOutcomeEngine.ts` + `TodayView.tsx:353-357` | rulat `trullasOutcomeEngine.test.ts` → **trece** |
| Panou „Review & Calitatea Semnalelor Shadow" | `TodayView.tsx:1010-1045` | secțiunea există, randează P&L net din motor |
| Universe selector S&P500/NDX100/Toate | `TodayView.tsx:246,797-807`, `dailyWatchlistStore.ts:24` | comutator funcțional pe datele watchlist-ului |

**Teste rulate acum, nu doar citite:** `npx tsx --test` pe toate fișierele `*.test.ts` noi → **17/18 trec**. Singurul eșec (`dailyWatchlistStore.test.ts`) e pentru că pachetul `firebase` nu era instalat în verificarea mea rapidă (izolată, fără `npm install`) — nu un bug de cod; am confirmat separat că `@luxalgo/*` și `pinets` (dependențele "exotice") chiar există pe npm, deci un `npm install` normal ar trece.

## 2. Scris, dar NEconectat la nimic real (schelă, nu implementare)

| Item | Ce există | De ce nu contează încă |
|---|---|---|
| `canTrade()` ca gate real pentru bot | funcția e corectă | `automatedPortfolio.ts` și `optionsAutomatedPortfolio.ts` (bot-urile care chiar "tranzacționează") **nu o importă deloc** — am verificat cu grep pe toate cele 3 fișiere ale motorului de bot: zero referințe la `canTrade`/`masterPlanCore` |
| `chartRouter.ts` (router unic `openChart()`) | scris, testat (1/1 trece) | **zero importatori** în afară de propriul test — `ChartViewer.tsx`/`TrendSpiderSuite.tsx` nu-l folosesc |
| `scanService.ts` (scan unic + cache) | scris, testat (1/1 trece) | **zero importatori** în afară de propriul test — `LiveScanner.tsx`/`MarketHeatmap.tsx` au rămas pe logica lor veche |
| Capital/risc reglabile din Settings | funcționează în `TodayView` | botul real citește alt număr (vezi mai jos) — setarea nu ajunge unde contează |
| Tabelul `signals` (shadow, persistat) | conceptul e portat în motor | **nu există nicio colecție Firestore pentru semnale** — am căutat `collection(` în tot `src/`: singura colecție reală e `journalEntries` (+ acum `watchlistItems`). Panoul "Calitatea semnalelor" din Today recalculează la fiecare load dintr-un set fix, **nu acumulează istoric real** — exact ca prototipul meu, nu dincolo de el |
| `bot_state`, `universe_members`, `strategy_stats` (schema SQL) | n-au echivalent Firestore | schema mea era pentru Postgres; nu există migrare pentru Firestore — vezi §4 |

## 3. Bug-uri noi, concrete (nu doar lipsuri)

1. **`masterPlanCore.ts:506`** — `Math.floor((maxRiskPerTrade * (sizeMultiplier || 1.0)) / unitRisk)`. Când regimul blochează direcția (`sizeMultiplier = 0`), `0 || 1.0` evaluează la **1.0** în JS (0 e falsy) — verificarea #7 (mărime) afișează o cantitate calculată cu multiplicator 1,0× în loc de 0×. Nu lasă botul să tranzacționeze (verificarea #9 tot blochează global), dar afișează traderului o cifră falsă pentru "ce ar fi luat". O linie de reparat: `sizeMultiplier > 0 ? sizeMultiplier : 0` în loc de `|| 1.0`.
2. **`OptionsAutomatedPortfolioManager.tsx:551`** — eticheta "Exceptional Asymmetry" sub Profit Factor e necondiționată (fără gate pe `totalTradesCount`). E exact bug-ul "PF 99x la n mic" din audit — **fixat în `TradeJournalView` dar nu și aici**, pe modulul paralel de opțiuni.
3. **Patch hardcodat suspect** în `optionsAutomatedPortfolio.ts:785-818` — cod care forțează `startingBalance/cash/equity = 2000` dacă detectează anumite ID-uri de poziție (`'nov12'`, `'opt-pos-es-'`). Arată ca o reparație rapidă, pe loc, a unei stări corupte găsite în timpul lucrului — merită înțeles înainte să fie lăsat în producție.
4. **Patru cifre de "capital" diferite, nesincronizate**, exact problema de suprapunere pe care o cerea planul s-o elimine:
   - `masterPlanCore.ts`: `simCapitalUsd = 2000` (nou, dar izolat în tab-ul Today)
   - `riskSettings.ts`: `accountEquity = 25000` (vechi, folosit de `PositionCalculatorModal`)
   - `automatedPortfolio.ts`: `initialCapital = 10000` (vechi, botul de acțiuni)
   - `optionsAutomatedPortfolio.ts`: `startingCapital = 2000` (vechi, botul de opțiuni — coincidență cu cifra nouă, nu legătură reală)
5. `Math.random()` încă prezent în `TrendSpiderSuite.tsx:143` (alegere aleatorie de simbol la pornire) — pare cosmetic (nu afectează calculul indicatorilor), dar merită confirmat că nu alimentează nimic determinist.

## 4. Arhitectură: Firebase/Firestore, nu Supabase/Postgres

`package.json` → `firebase: ^13.3.0`, `src/lib/firebase.ts`, `firestore.rules`, `firebase-blueprint.json`. **`schema.sql` e gol (0 octeți).** Asta confirmă: platforma AI Studio folosește nativ Firebase, nu Supabase cum presupunea documentul tău original de schemă ("Supabase DDL"). Pentru tine, asta înseamnă:

- Tot ce am scris în `trullas-schema-v3-delta.sql` (view-uri SQL, `security_invoker`, `CHECK` constraints, RLS cu `auth.uid()`) **nu se poate aplica direct** — Firestore nu are view-uri SQL, triggere sau constrângeri declarative la nivelul acela. Echivalentul Firestore (reguli de securitate + validare pe scriere) a fost făcut *corect*, dar doar pentru 2 din cele ~8 colecții noi din planul meu (`journalEntries`, `watchlistItems`) — lipsesc `signals`, `bot_state`, `bot_events`, `universe_members`, `strategy_stats`, `config_changelog`.
- Testele numerice pe care le-am rulat eu (202 verificări vs. scipy, 14 teste negative, RLS activ) au validat **schema Postgres**, nu ce rulează acum în producție. Nu sunt înșelătoare — au validat corect ce-am livrat — dar nu validează build-ul tău real din AI Studio.
- `trullas-ai-implementation-prompt.md` (promptul pe care l-am scris) presupune Postgres/Supabase în instrucțiunile de validare (§6: pglast, RLS cu `set_config`). Dacă rămâi pe AI Studio/Firebase, acel prompt trebuie rescris pentru Firestore (reguli de securitate + o colecție `signals` cu agregare client-side sau Cloud Functions, nu view-uri SQL).

## 5. Răspuns direct la "s-a rezolvat suprapunerea?"

Nu încă — de fapt pare puțin mai rea. Tab-ul nou "Today" a fost **adăugat** lângă toate cele ~20 de tab-uri vechi (Live Scanner, TrendSpider Suite, Market Heatmap, Automated Portfolio Manager, Options Automated Portfolio Manager, Action Dashboard, Confluence Matrix, LuxAlgo Suite, Trading Warz Engine...) — niciunul n-a fost scos sau unificat. Exact mecanismul "strangler" din promptul meu (ține codul vechi până noul modul atinge paritate testată, **apoi** șterge vechiul) nu s-a aplicat — s-a făcut doar jumătatea 1 (cod nou), nu și jumătatea 2 (migrarea celui vechi pe el + ștergere).

## Recomandare

Următorul pas cel mai valoros nu e "mai mult cod", e **conectarea** a ce există deja: fă `automatedPortfolio.ts`/`optionsAutomatedPortfolio.ts` să cheme `canTrade()` din `masterPlanCore.ts` în loc de regulile lor proprii, și unifică cele 4 cifre de capital într-una singură (`masterPlanCore.ts`'s Settings, scris pe Firestore, citit de toți). Asta e un task mic, cu impact mare — spune-mi dacă vrei promptul de AI actualizat exact pentru asta (varianta Firebase, nu Postgres).
