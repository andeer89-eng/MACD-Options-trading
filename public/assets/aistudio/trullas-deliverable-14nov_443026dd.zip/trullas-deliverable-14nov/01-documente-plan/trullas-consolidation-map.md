# TRULLAS — Harta de consolidare a celor 19 module (2026-11-13/14)

Verificat direct în codul live extras (export 12 nov, 13:53), fișier cu fișier, nu doar
după numele tab-urilor. Fiecare afirmație de mai jos are citare `fișier:linie`. Acest
document actualizează și înlocuiește Anexa A din `trullas-master-plan-v3.md` (scrisă
înainte să văd codul real) cu maparea reală, bazată pe dovezi.

## Verdict într-un paragraf

Cele 19 tab-uri din `Header.tsx` (`ALL_TABS`) nu sunt 19 funcții diferite — sunt în
jur de **11-12 motoare reale**, dintre care unele sunt folosite de 2-4 tab-uri deodată
(suprapunere reală) și altele sunt complet izolate (șanse de curățare ușoară). Am
rezolvat deja, în acest build, cel mai valoros punct de suprapunere (botul care
tranzacționează efectiv nu știa de `canTrade()`) și silozul de watchlist-uri
(Scanner vs. tab-ul Watchlists). Rămân patru clustere mari de suprapunere (mai jos),
plus o descoperire importantă: tab-ul "Today" — cel mai fidel planului v3 — rulează
încă pe date seed/mock (`SPDR_SECTORS`, `SEED_WATCHLIST_DEF`, `regimeComponents`
hardcodate în `TodayView.tsx`), nu pe un scan live. Asta schimbă prioritatea:
înainte de a muta mai mult cod, trebuie conectat Today la date reale.

---

## 1. Cele 19 tab-uri → motor real → ecran țintă (Master Plan v3 §4)

| # | Tab (`Header.tsx`) | Componentă | Motor/store real (fișier:linie) | Ecran țintă v3 | Stare |
|---|---|---|---|---|---|
| 1 | `today` | `TodayView.tsx` | `masterPlanCore.ts` (canTrade/Levels/Settings), `trullasOutcomeEngine.ts`, `dailyWatchlistStore.ts` (Firestore) | **TODAY** | Motor real + testat, dar UI rulează pe **date mock** (vezi §3.5) |
| 2 | `scanner` | `LiveScanner.tsx` | `confluenceScoringEngine.ts` + `WatchlistManager.tsx` (acum pe `watchlistManager.ts`, **fixat** azi) | SCAN LAB | Activ |
| 3 | `confluence` | `ConfluenceMatrixView.tsx` | **același** `confluenceScoringEngine.ts` ca #2 | SCAN LAB | Suprapunere directă cu #2 |
| 4 | `action-zones` | `ActionDashboard.tsx` | `tradeActionEngine.ts` (motor diferit de #2/#3) | TODAY/SCAN LAB | Al 3-lea motor pentru aceeași întrebare |
| 5 | `chart` | `ChartViewer.tsx` | `trullasStrategy.ts` + `luxalgoIndicators.ts` + `indicatorLibrary.ts` + `heikinAshi.ts` | **CHART** | Deja agregă 3 motoare — e cel mai aproape de „un singur Levels" din §4.2 |
| 6 | `options` | `CboeOptionsAnalytics.tsx` | `cboeOptionsEngine.ts` | TODAY (context) | Standalone, OK |
| 7 | `heatmap` | `MarketHeatmap.tsx` | `heatmapEngine.ts` | TODAY (Regime) | Vezi §3.3 |
| 8 | `sectors` | `SectorPerformanceView.tsx` | `sectorMetrics.ts` | TODAY (RRG) | Vezi §3.3 |
| 9 | `watchlists` | `WatchlistManagerView.tsx` | `watchlistManager.ts` | TODAY (watchlist) | **Fixat azi** — #2 folosește acum același store |
| 10 | `journal` | `TradeJournalView.tsx` | `tradeJournal.ts` + montează `AutomatedPortfolioManager` + `OptionsAutomatedPortfolioManager` | REVIEW + AUTOPILOT | 3 concepte într-un singur tab |
| 11 | `backtester` | `BacktesterView.tsx` | `backtestEngine.ts` + `strategyOptimizer.ts` | SCAN LAB (buton) + REVIEW | Izolat — fără „Backtest this setup" pe rândurile de scan |
| 12 | `luxalgo` | `LuxAlgoSuite.tsx` | `luxalgoIndicators.ts` — **același** modul ca #5 | CHART (panou) | Suprapunere directă cu #5 |
| 13 | `indicators` | `IndicatorLibraryView.tsx` | `indicatorLibrary.ts` — **același** modul ca #5 | CHART (panou) | Suprapunere directă cu #5 |
| 14 | `trendspider` | `TrendSpiderSuite.tsx` | `trendSpiderEngine.ts` (motor separat, reverse-engineered) | CHART | Risc IP/marcă — vezi §4.1 |
| 15 | `rules` | `StrategyGuide.tsx` | — (conținut static) | SETTINGS (referință) | Fără suprapunere, doar loc greșit |
| 16 | `alerts` | `AlertStream.tsx` | `alertFilter.ts` + `dataFetcher.ts` | SETTINGS/global | Decizie de design, nu bug — vezi §4.2 |
| 17 | `health` | `SystemHealthView.tsx` | `systemHealth.ts` | **SETTINGS** | Fără suprapunere |
| 18 | `sec` | `SecEdgarInspector.tsx` | — (apeluri directe EDGAR, fără motor propriu) | TODAY (smart money, §4.1) | Fără suprapunere, doar loc greșit |
| 19 | `python` | `PythonDaemonView.tsx` | — (generează script, text) | SETTINGS | De clarificat (vezi Anexa A veche — „înlocuit de worker") |

**Deci:** 19 tab-uri, dar doar ~12 motoare, dintre care 3 sunt folosite de 2+ tab-uri
(`confluenceScoringEngine`, `luxalgoIndicators`, `indicatorLibrary`) și unul e
folosit de 0 tab-uri în logica de business reală (`masterPlanCore.canTrade` —
**era** 0 înainte de azi; acum e în `automatedPortfolio.ts` și
`optionsAutomatedPortfolio.ts`, plus `TodayView.tsx`).

---

## 2. Ce am rezolvat deja în acest build (verificat cu teste, nu doar descris)

| Fix | Fișier | Dovadă |
|---|---|---|
| `canTrade()` cablat ca gate real în botul de acțiuni | `automatedPortfolio.ts` (import linia ~23, gate la linia ~956-1050) | Test ad-hoc: poziție **blocată** în regim Risk-off, **deschisă** în Risk-on — reprodus determinist, independent de ora reală |
| `canTrade()` cablat ca gate real în botul de opțiuni | `optionsAutomatedPortfolio.ts` (gate la linia ~568-650) | Idem; verificare #7 (mărime în $) exclusă explicit pentru opțiuni — motivat în §4.2 mai jos |
| Bug `sizeMultiplier \|\| 1.0` | `masterPlanCore.ts:506` | `0 \|\| 1.0` evalua fals la 1.0 în JS — reparat la `sizeMultiplier > 0 ? sizeMultiplier : 0` |
| Bug "Exceptional Asymmetry" necondiționat | `OptionsAutomatedPortfolioManager.tsx:549-556` | Acum condiționat de `totalTradesCount >= 10`, oglindă exactă a fix-ului deja corect din `TradeJournalView.tsx` |
| Siloz watchlist Scanner ↔ tab Watchlists | `WatchlistManager.tsx` rescris pe `watchlistManager.ts` în loc de `watchlist.ts` (șters, 0 importatori rămași) | Teste `watchlistManager.test.ts`: 8/8 trec |
| Regresie descoperită și reparată în timpul lucrului | ambele bot-uri | Gate-ul meu bloca orice tranzacție sâmbăta (weekend) chiar și cu `allowExtendedHours=true` — pentru că verificarea de calendar din `canTrade()` nu știa de acel flag. Reparat: `marketOpenOverride: symRegime.isOpen \|\| allowExtendedHours` în ambele fișiere, ca să nu introduc o a doua sursă de adevăr care contrazice flagul existent al botului |
| Teste | `npx tsx --test src/utils/*.test.ts` → **121/125 trec**. Cele 4 eșecuri sunt **pre-existente**, de mediu (`Cannot find package 'firebase'` / `'@luxalgo/journal-core'` — pachete reale, doar neinstalate în acest sandbox fără `npm install`), nicio legătură cu modificările de azi |  |

---

## 3. Clustere de suprapunere rămase (evidență + recomandare)

### 3.1 „Ce tranzacționez azi" — 4 tab-uri, 3 motoare, 1 singur are gate-ul de risc

`today` + `scanner` + `confluence` + `action-zones` răspund toate la aceeași
întrebare, dar:
- `scanner` și `confluence` folosesc `confluenceScoringEngine.ts` (grilă pe 6 unghiuri)
- `action-zones` folosește `tradeActionEngine.ts` (pipeline pe 7 stadii) — un al treilea motor
- Doar `today` aplică `canTrade()` — rezultatele din celelalte 3 tab-uri pot arăta
  un setup "bun" pe care botul/regimul l-ar bloca oricum

**Recomandare:** nu șterge niciunul din cele 3 motoare de scoring (fiecare are o
logică distinctă și validă — 6-unghiuri vs. 7-stadii nu sunt duplicate, sunt
perspective diferite pe aceleași date). În schimb:
1. Fă ca toate cele 3 (`scanner`, `confluence`, `action-zones`) să cheme
   `canTrade()` înainte de a afișa un rând ca "tranzacționabil", exact cum am
   făcut-o deja pentru cele 2 boturi — astfel încât un rând blocat de regim/risc
   să fie marcat la fel peste tot, nu doar în `today`.
2. Fă ca toate 4 să citească din **`scanService.ts`** (deja scris, deja testat
   1/1, dar cu **zero importatori reali** — am verificat cu grep) în loc să ruleze
   fiecare propriul scan. Asta era exact intenția din §4.3 a planului
   ("Un singur `scanService`... consumat de toate UI-urile") — a fost construit,
   dar nu conectat.

### 3.2 Chart — deja parțial unificat, dar `luxalgo` și `indicators` sunt tab-uri duplicate ale acelorași module

`ChartViewer.tsx` importă deja direct din `luxalgoIndicators.ts` (linia 53) și
`indicatorLibrary.ts` (linia 55) — deci graficul principal e deja aproape de
„un singur Levels" cerut în §4.2. Dar `luxalgo` și `indicators` există și ca
**tab-uri separate** care arată aceleași module printr-o UI proprie, paralelă.

**Recomandare:** mută `LuxAlgoSuite.tsx` și `IndicatorLibraryView.tsx` ca panouri
colapsabile **în interiorul** `chart` (exact ca modelul deja aplicat cu
`WatchlistManager` în `LiveScanner`), nu ca tab-uri de nivel-1. Reduce 3 tab-uri
(`chart`+`luxalgo`+`indicators`) la 1, fără să ștergi nicio funcționalitate.
`chartRouter.ts` (router unic `openChart()`, scris, testat 1/1, **zero
importatori**) e exact piesa lipsă pentru ca `ChartViewer.tsx` și
`TrendSpiderSuite.tsx` să deschidă grafice printr-un singur punct de intrare.

### 3.3 Sectors vs. Heatmap vs. RRG din Today — trei vederi pe structura pieței, date neclar-sincronizate

`sectors` (`sectorMetrics.ts`) și `heatmap` (`heatmapEngine.ts`) sunt module
**diferite** (nu duplicate de cod), dar `TodayView.tsx` are propriul panou RRG
cu un `SPDR_SECTORS` **hardcodat local** (liniile 56-68 — 11 ETF-uri SPDR cu RS/
momentum scrise manual, nu calculate din `sectorMetrics.ts`). Rezultatul: dacă
`sectorMetrics.ts` arată Technology în frunte, iar panoul RRG din Today arată alt
clasament (pentru că e o listă fixă), utilizatorul vede 2 "adevăruri" diferite.

**Recomandare:** `TodayView.tsx` trebuie să cheme `sectorMetrics.ts` pentru
panoul RRG, nu lista hardcodată. (Nu am făcut acest fix azi — necesită să văd
mai întâi dacă `sectorMetrics.ts` calculează deja RS pe orizonturi multiple a
la RRG, sau doar un clasament simplu; marchez ca item P1, nu P0.)

### 3.4 Journal — 3 concepte, 1 tab, fiecare cu propriul "capital"

`journal` montează `TradeJournalView` + `AutomatedPortfolioManager` ($10k,
`automatedPortfolio.ts`) + `OptionsAutomatedPortfolioManager` ($2k,
`optionsAutomatedPortfolio.ts`). Concluzia rafinată din audit rămâne valabilă:
**nu** unifica cele 3 cifre de capital într-una singură — fiecare reprezintă
P&L simulat real, acumulat separat, și suprascrierea lui ar fi o pierdere de
date, nu o curățare. Ce chiar trebuie unificat (și am făcut-o azi) e
**politica de risc %** — ambele boturi citesc acum din același
`masterPlanCore.loadSettings()`.

### 3.5 Descoperire nouă: `TodayView.tsx` rulează pe date mock, nu pe scan live

Verificat la liniile 56-68 (`SPDR_SECTORS`) și 71-130+ (`SEED_WATCHLIST_DEF`,
NVDA/LLY/JPM cu prețuri și scoruri scrise manual) și 250-255 (`regimeComponents`
inițializat cu `useState` la valori fixe, niciodată actualizate dintr-un fetch
real). Acesta e tab-ul cel mai fidel planului v3 din punct de vedere al
motorului (`canTrade`, `Levels`, gate-ul pe 10 verificări — toate reale și
testate), dar **intrările** din UI sunt încă demo. Practic: motorul de decizie e
gata; alimentarea lui cu date live din `scanService`/`sectorMetrics`/scanner-ul
real nu e făcută încă.

**De ce contează pentru prioritizare:** cablarea `canTrade()` în cele 2 boturi
(făcută azi) e valoroasă independent de asta — botul folosește deja propriile
lui date live de preț (`item.currentPrice`, `item.atr` din `marketItems`), nu
seed-ul din Today. Dar panoul vizual din Today pe care utilizatorul îl vede nu
reflectă încă regimul real al pieței — e următorul pas cel mai valoros, înaintea
oricărei mutări suplimentare de UI.

---

## 4. Puncte care au nevoie de decizia ta explicită

### 4.1 `trendSpiderEngine.ts` — risc de marcă înregistrată / reverse-engineering

Fișierul reverse-engineers algoritmii unui produs comercial terț (Weinstein
4-stage, "Raindrop® Charts" — simbolul ® e chiar în cod, Auto-AVWAP, trendlines
automate) și expune un al 4-lea scor propriu ("TrendSpider Confluence Score
0-100", separat de `confluenceScoringEngine.ts`). Nu pot evalua riscul legal —
nu sunt avocat — dar semnalez clar: numele „TrendSpider" și simbolul „Raindrop®"
apar în UI (`TrendSpiderSuite.tsx`, badge "Stage 4 🩸" în `Header.tsx:207-210`)
ca și cum ar fi un produs licențiat, când de fapt e o reimplementare proprie.

**Decizie necesară:** (a) păstrezi engine-ul dar elimini orice referință la
numele/marca "TrendSpider" și simbolul ® din UI și cod, redenumind ca motor
propriu Trullàs; sau (b) consulți un jurist înainte să decizi; eu nu pot alege
pentru tine pe partea legală.

### 4.2 Scanner/Confluence/Action-Zones/Today — fuziune completă sau separare parțială?

Din §3.1: ai 3 motoare de scoring valide, nu duplicate inutile. Variantele:
- **(a) Fuziune completă:** 1 singur tab "Scan" cu cele 3 scoruri ca 3 coloane/
  taburi interne, plus gate-ul `canTrade()` aplicat la toate — maxim de
  „aerisit", dar o rescriere de UI mai mare.
- **(b) Separare parțială (recomandarea mea):** păstrezi cele 4 tab-uri (fiecare
  motor are valoare distinctă), dar le faci pe toate să cheme `canTrade()` și
  `scanService.ts` — consolidezi *motorul de date*, nu neapărat *numărul de
  tab-uri*. Mai puțin risc, impact aproape la fel de mare.

### 4.3 Check #7 din `canTrade()` pentru boturi de opțiuni — formulă nouă, sau rămâne „doar informativ"?

Azi am exclus explicit verificarea de mărime minimă ($-risc-per-contract vs.
`simCapitalUsd`×1%) din decizia de blocare pentru botul de opțiuni (vezi
`optionsAutomatedPortfolio.ts`, comentariul de lângă `blockingFails`) — pentru
că formula a fost gândită pentru acțiuni (risc per acțiune) și blochează
practic orice contract MES/ES pe un cont de $2.000. Varianta corectă pe termen
lung: un câmp separat în Settings (ex. `optionsMaxRiskPerTradePct`) cu propria
lui formulă de risc (prima plătită / colateral, nu distanță-până-la-strike).
Nu am implementat asta azi (ar fi schimbat `canTrade()`-ul de bază, folosit și
de acțiuni, fără validare suplimentară) — rămâne item P1 explicit, cu codul
deja pregătit să-l primească (`gate.fails` e deja filtrat pe `shortName`).

---

## 5. Ordine recomandată pentru pașii următori (dacă continuăm)

1. **P0** — Conectează panoul Regime/RRG din `TodayView.tsx` la date reale
   (din `sectorMetrics.ts` + un fetch real, nu `SPDR_SECTORS`/`regimeComponents`
   hardcodate) — fără asta, `regimeScore` transmis boturilor rămâne un parametru
   opțional nefolosit de nimeni în producție.
2. **P0** — Decizia 4.1 (TrendSpider®/marcă) — blocant legal potențial, merită
   rezolvat înaintea oricărei lansări publice.
3. **P1** — Conectează `scanner`/`confluence`/`action-zones` la `scanService.ts`
   și la `canTrade()` (§3.1).
4. **P1** — Decizia 4.2 (nivelul de fuziune UI).
5. **P1** — Mută `luxalgo`/`indicators` ca panouri în `chart` via `chartRouter.ts`
   (§3.2) — reduce 19 tab-uri la 17 fără pierdere de funcționalitate.
6. **P2** — `sectors` vs. RRG din Today (§3.3) — verifică întâi dacă
   `sectorMetrics.ts` oferă deja datele pe orizonturi multiple necesare RRG.
7. **P2** — Formula de risc separată pentru opțiuni în `canTrade()` (§4.3).
