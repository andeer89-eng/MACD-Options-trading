# Prompt de execuție — TRULLAS Master Plan v3 (varianta Firebase, 2026-11-14)

Copiază tot ce urmează într-un agent de coding (Claude Code, Cursor, etc.)
**împreună cu fișierele atașate**:
`trullas-master-plan-v3.md`, `trullas-consolidation-map.md`,
`trullas-audit-implementare-12-13nov.md`, `trullas-schema-v3-delta.sql` (context
istoric — vezi §0.2, NU e sursa de adevăr pentru persistență),
`trullas-outcome-engine.js`, `trullas-today-prototype.html`, și **arhiva cu
fișierele sursă deja modificate** din acest build (vezi §0.1).
Acestea sunt sursa de adevăr — acest prompt doar le pune în ordine de execuție.
Dacă ceva din prompt contrazice un fișier, câștigă fișierul.

**Diferență față de versiunea anterioară a acestui prompt:** versiunea veche
presupunea Postgres/Supabase (bazat pe documentul original de schemă). Codul
real din AI Studio rulează pe **Firebase/Firestore** (`firebase: ^13.3.0`,
`src/lib/firebase.ts`, `firestore.rules`, `firebase-blueprint.json`) + un
server Express propriu (`server.ts`, 1211 linii, rulează deja majoritatea
motoarelor server-side). `schema.sql` e gol (0 octeți) — nu există și nu va
exista un Postgres real pe acest build. Tot ce urmează e rescris pentru asta.

---

## 0. Linia de pornire reală — NU pornești de la zero

### 0.1 Deja implementat și testat în acest build (nu refă)

| Item | Fișier | Dovadă |
|---|---|---|
| `canTrade()` cablat ca gate real în botul de acțiuni | `src/utils/automatedPortfolio.ts` (import ~linia 23; gate ~liniile 956-1050, înainte de `calculatePositionSize`) | Poziție blocată determinist în regim Risk-off, deschisă în Risk-on; 8/8 teste existente trec |
| `canTrade()` cablat ca gate real în botul de opțiuni | `src/utils/optionsAutomatedPortfolio.ts` (gate ~liniile 568-650) | 5/5 teste existente trec; verificarea #7 (mărime în $) exclusă motivat pentru opțiuni — vezi §3 |
| Bug `sizeMultiplier \|\| 1.0` (afișa cantitate falsă când regimul blochează) | `src/utils/masterPlanCore.ts:506` | Reparat la `sizeMultiplier > 0 ? sizeMultiplier : 0` |
| Bug „Exceptional Asymmetry" necondiționat la n mic | `src/components/OptionsAutomatedPortfolioManager.tsx:549-556` | Condiționat acum de `totalTradesCount >= 10`, oglindă a fix-ului din `TradeJournalView.tsx` |
| Siloz watchlist Scanner ↔ tab Watchlists | `src/components/WatchlistManager.tsx` rescris pe `watchlistManager.ts`; `watchlist.ts` (vechiul store, 0 importatori) șters | `watchlistManager.test.ts` 8/8 trece |
| Capital/risc reglabile, fără constante hardcodate | `masterPlanCore.ts` (`loadSettings`/`saveSettings`/`getRiskUsd`) | Testat în `masterPlanCore.test.ts` 4/4 |
| Harta completă de suprapuneri pe cele 19 tab-uri | `trullas-consolidation-map.md` | Vezi §2 mai jos — e lista de task-uri rămase, cu dovezi `fișier:linie` |

**Nu redeschide niciunul din aceste 5 fix-uri ca și cum ar fi de făcut.** Pornește
de la ele. Rulează întâi `npx tsx --test src/utils/*.test.ts` pe arhiva primită
ca să confirmi starea (ar trebui: 121/125 — cele 4 eșecuri sunt de mediu,
`Cannot find package 'firebase'`/`'@luxalgo/journal-core'`, dispar după
`npm install` real).

### 0.2 Ce NU se aplică din materialul vechi

`trullas-schema-v3-delta.sql` (580 linii, validat pe un Postgres real) rămâne
atașat doar ca **referință de intenție** — ce tabele/view-uri/constrângeri
trebuiau să existe conceptual (`signals`, `bot_state`, `bot_events`,
`universe_members`, `exit_policies`, view-urile `v_signal_*`). Niciun `CREATE
TABLE`/`CREATE VIEW`/`CHECK CONSTRAINT`/RLS din el nu se aplică direct — nu
există Postgres. §2 de mai jos traduce fiecare concept în Firestore.

---

## 1. Cine ești și regulile de aur (nu se negociază)

Ești un agent de implementare full-stack pe **TRULLAS Divergence 24/7
Scanner** — React 19/Vite + **Firebase/Firestore** + un server Express propriu
(`server.ts`) care rulează deja motoarele de calcul server-side. Lucrezi pe
codul existent ca o **migrare strangler**: păstrezi tab-urile/componentele
actuale până ating paritate testată cu ce consolidezi, apoi le ștergi sau le
colapsezi — nu rescrii totul de la zero, și nu ștergi un motor de scor doar
pentru că pare „similar" cu altul (vezi `trullas-consolidation-map.md` §3.1 —
cele 3 motoare de scoring din Scanner/Confluence/Action-Zones sunt perspective
diferite, nu duplicate).

Reguli care se aplică la FIECARE task de mai jos, fără excepție:
1. **Determinism.** Niciun indicator, scor sau nivel nu se calculează cu
   `Math.random()` sau orice sursă nedeterministă în cod de producție.
   Aceleași bare de intrare → aceleași rezultate, întotdeauna. (Excepție
   cunoscută, de verificat: `TrendSpiderSuite.tsx:143` are un `Math.random()`
   la alegerea simbolului de pornire — pare cosmetic, confirmă că nu alimentează
   niciun calcul de indicator înainte să-l consideri „ok".)
2. **Fără „AI features".** Niciun chatbot, niciun LLM în bucla de decizie.
   Dacă un task pare să ceară asta, nu-l faci — flagging, nu implementare.
3. **UI dark (zinc-900)**, consecvent cu restul platformei.
4. **Anti look-ahead.** Un semnal/marker se *datează* la bara la care devine
   cunoscut (`confirmed_bar_ts`), nu la bara pivotului. Intrarea e la
   deschiderea barei următoare după confirmare. Dacă SL și TP cad în aceeași
   bară → **SL câștigă**.
5. **Niciun calcul de business în componente React.** Logica de scor/nivel/
   gate trăiește în `src/utils/*.ts` (client) sau `server.ts` (server), nu în
   JSX. `canTrade()`/`calculateLevels()` din `masterPlanCore.ts` sunt deja așa
   — urmează același tipar pentru orice motor nou.
6. **Orice cifră afișată** (KPI, statistică, R, P&L) poartă lângă ea: `n`,
   CI90 dacă există, calitatea datelor, și „as of". Fără cifră „goală" —
   exact bug-ul deja reparat o dată la Profit Factor (§0.1); nu-l reintroduce
   într-un panou nou.
7. **Un item din §2 (roadmap) = un PR.** Nu începi item-ul N+1 până nu trec
   criteriile de acceptare ale item-ului N (minim: testele relevante trec cu
   `npx tsx --test`, plus pașii din §4). Dacă un criteriu nu poate fi
   verificat, oprește-te și raportează — nu marca „done" pe baza unei
   presupuneri.
8. **Nicio colecție Firestore nouă fără reguli de securitate scrise și
   testate** (vezi §4) — exact modelul deja aplicat corect pentru
   `journalEntries`/`watchlistItems` în `firestore.rules`.
9. **Nu introduce o a doua sursă de adevăr care contrazice una existentă.**
   Am găsit și reparat exact acest bug azi: gate-ul `canTrade()` bloca orice
   tranzacție în weekend chiar și cu `allowExtendedHours=true`, pentru că
   verificarea lui de calendar nu știa de acel flag deja existent în bot.
   Fixul: `marketOpenOverride: symRegime.isOpen || allowExtendedHours` — când
   adaugi o verificare nouă peste un flag/stare deja existentă, combin-o
   explicit, nu o lăsa să decidă singură.

---

## 2. Harta de consolidare — ordinea de execuție (din `trullas-consolidation-map.md` §5)

Lista completă de suprapuneri, cu dovezi `fișier:linie`, e în
`trullas-consolidation-map.md`. Mai jos e ordinea de execuție recomandată —
tratează fiecare linie ca un item de roadmap (regula §1.7: un item = un PR).

### P0 — Deja parțial făcut azi; rămas de completat
1. ~~`canTrade()` cablat în boturi~~ — **FĂCUT** (§0.1). Rămâne: cablează-l și
   în `scanner`/`confluence`/`action-zones` (afișează un rând ca blocat de
   regim/risc dacă `canTrade()` ar refuza, nu doar afișează scorul brut).
2. **Conectează panoul Regime/RRG din `TodayView.tsx` la date reale.**
   `SPDR_SECTORS` (liniile 56-68) și `SEED_WATCHLIST_DEF` și
   `regimeComponents` (liniile ~250-263) sunt hardcodate/mock — niciun fetch
   real. Fără asta, parametrul `regimeScore` pe care l-am adăugat deja ca
   opțional în `processAutonomousCycle()`/`processOptionsAutonomousCycle()`
   n-are cine să-l alimenteze cu o valoare reală în producție. Sursa de
   adevăr pentru sectoare ar trebui să fie `sectorMetrics.ts` (vezi §3.3 din
   map), nu o listă scrisă manual.
3. **Decizia TrendSpider®** (`trullas-consolidation-map.md` §4.1) — risc de
   marcă înregistrată/reverse-engineering. **Nu decide tu** — vezi §6
   „Când ești blocat". Dacă proprietarul a decis deja (verifică mesajul lui de
   răspuns la acest prompt sau un fișier `DECISIONS.md` dacă există), aplică
   decizia; altfel oprește-te la acest item.
4. Banner „SIMULATED DATA" + „as of" global + export/import JSON — verifică
   dacă `exportMasterPlanBackup()`/`importMasterPlanBackup()` din
   `masterPlanCore.ts` (deja scrise) sunt conectate la un buton real în UI;
   dacă nu, conectează-le (nu rescrie logica, există deja).

### P1 — Consolidare de motor și UI
5. Conectează `scanner` (`LiveScanner.tsx`), `confluence`
   (`ConfluenceMatrixView.tsx`), `action-zones` (`ActionDashboard.tsx`) și
   `heatmap` (`MarketHeatmap.tsx`) la **`scanService.ts`** (deja scris, deja
   testat 1/1, **zero importatori reali** — verifică cu grep înainte să
   presupui că s-a schimbat) în loc să ruleze fiecare propriul scan.
6. Decizia de fuziune UI pentru clusterul „ce tranzacționez azi" (map §4.2) —
   fuziune completă într-un singur tab vs. păstrarea celor 4 cu motor comun.
   **Decizie a proprietarului**, nu a ta — vezi §6.
7. Mută `LuxAlgoSuite.tsx` și `IndicatorLibraryView.tsx` ca panouri
   colapsabile **în interiorul** `chart` (modelul deja aplicat cu
   `WatchlistManager` în `LiveScanner` — vezi `src/components/LiveScanner.tsx`
   liniile ~511-519 pentru tipar). Conectează `ChartViewer.tsx` și
   `TrendSpiderSuite.tsx` la **`chartRouter.ts`** (scris, testat 1/1, zero
   importatori) ca punct unic `openChart()`.
8. Migrarea completă pe colecțiile Firestore noi — vezi §4 mai jos
   (`signals`, `bot_events`, `universe_members`, `strategy_stats`).
9. Worker + scheduler în două straturi (Tier 1 EOD / Tier 2 la 5 min) — rulează
   în `server.ts` (deja are infrastructura Express) sau ca job separat
   invocat de un scheduler extern (ex. Cloud Scheduler → endpoint HTTP în
   `server.ts`, sau cron/systemd ca în `PythonDaemonView.tsx`-ul existent,
   care deja generează acest tipar de script — reutilizează ideea, nu o
   reinventa). Heartbeat scris într-un document `bot_events`.
10. **Spike R** (1 zi): forward returns SPY pe benzile Regime Score — confirmă
    sau infirmă greutățile din plan §6.1 înainte de a construi pe ele.
    **Spike E** (2 zile): backtest 5 ani / 4 strategii cu costuri, vs.
    random-entry și vs. buy-and-hold SPY — folosește `backtestEngine.ts` +
    `strategyOptimizer.ts`, deja existente în `server.ts`.
11. Smart money din EDGAR (Form 4 cluster insideri, 13F cu lag etichetat
    explicit „context, nu semnal de timing") în `SecEdgarInspector.tsx` →
    mutat conceptual în panoul TODAY per plan §4.1.
12. Registru de universuri (`universe_members`: `sp500`, `ndx100`, uniune
    `sp500_ndx100`) ca document(e) Firestore + selector de univers în Scan
    Lab/TODAY + filtre de lichiditate.
13. **Spike P** (1 zi): verifică licența/prețul Nasdaq Data Link pentru uz
    automatizat, apoi reconciliere pe două surse în Tier 1 (câmp
    `dataQuality: 'estimated'` pe documentul de snapshot dacă diferența trece
    un prag).

### P2 — Învățare + rafinare
14. Tabelul `signals` (shadow) + outcome engine — portează **exact** logica
    din `trullas-outcome-engine.js` (cross-validată, 72 comparații, 0
    diferențe) — e deja portată parțial în `trullasOutcomeEngine.ts` și
    folosită în `TodayView.tsx:353-357`, dar **nu persistă istoric real**
    (recalculează la fiecare load dintr-un set fix — confirmat în audit).
    Scrie persistența reală în Firestore (vezi §4).
15. Panoul Review „Calitatea semnalelor" cu istoric real (nu doar recalculat
    la fiecare load) — structura UI deja există în
    `trullas-today-prototype.html` și în `TodayView.tsx:1010-1045`.
16. Learning loop v1: pauză automată la n≥30 și R mediu <−0,1R; boost
    candidat (aprobare manuală) la n≥100 și CI90 inferior >0; ecranul
    „Propuneri" în Review.
17. Formula de risc separată pentru opțiuni în `canTrade()` (map §4.3) — azi
    verificarea #7 e exclusă explicit din decizia de blocare pentru opțiuni
    (`optionsAutomatedPortfolio.ts`, `blockingFails`) pentru că formula de
    $-risc-per-contract vs. `simCapitalUsd`×1% nu se potrivește cu un cont
    de opțiuni sizat pe contracte fixe. Adaugă un câmp separat în
    `MasterPlanSettings` (ex. `optionsMaxRiskPerTradePct` +
    `optionsCapitalUsd`) cu propria formulă (primă plătită/colateral, nu
    distanță-până-la-strike), apoi elimină excepția din `blockingFails`.
18. `sectors` (`sectorMetrics.ts`) vs. RRG din Today vs. `heatmap`
    (`heatmapEngine.ts`) — verifică dacă `sectorMetrics.ts` oferă deja RS pe
    orizonturi multiple necesar pentru un RRG real; dacă da, elimină
    `SPDR_SECTORS` hardcodat (vezi item 2 de mai sus, sunt același fix).
19. Poarta paper→live (plan §6.4): cele 10 verificări `canTrade()` + cele 4
    noi (provider oficial de date, edge net de costuri din Spike E, n≥100/
    strategie cu CI90 inferior>0, 30 de zile paper fără incidente de
    gate/heartbeat).

### P3 (după, neconfirmat ca prioritate)
Replay bar-by-bar, aplicație mobilă, futures CME ca fluxuri de execuție reale.

---

## 3. `canTrade()` — cele 10 verificări (deja implementate, nu rescrie)

Implementarea reală e în `masterPlanCore.ts:415-568`, testată 4/4 în
`masterPlanCore.test.ts`, și cablată ca gate real în ambele boturi (§0.1).
Ordinea exactă (nu o schimba fără motiv documentat):

1. Calendarul NYSE e deschis (inclusiv program scurt, sărbători) — sau
   `marketOpenOverride` explicit al apelantului (vezi regula §1.9 — combină
   cu `allowExtendedHours`, nu-l lăsa singur).
2. Datele sunt `live` și proaspete (nu `cached`/`estimated`).
3. Kill switch armat + stare bot ≠ `paused`/`killed`.
4. Pierderea zilnică sub limită (`dailyLossLimitPct`). **Notă:** azi am lăsat
   `dailyLossPct` pe valoarea implicită (0, deci trece mereu) în ambele
   boturi — nu există încă o sursă reală de „pierdere realizată azi" la
   nivel de cont. E un gol cunoscut, nu un fals pozitiv; dacă îl implementezi,
   calculează-l din `account.realizedPnL` al zilei curente vs. echitatea de
   la începutul zilei (necesită un baseline persistat, nu doar `lastUpdated`).
5. Expunerea pe sector sub plafon — calculată azi **real**, din pozițiile deja
   deschise în ciclul curent (`automatedPortfolio.ts`, `sectorExposureUsd`),
   nu lăsată pe 0.
6. Strategia nu e în pauză.
7. Regula de mărime minimă — vezi excepția pentru opțiuni la item 17 din §2.
8. Lichiditate opțiuni (spread, open interest) — doar pentru simboluri cu
   opțiuni. Azi trece mereu (`optionsLiquidityOk: true` hardcodat) pentru că
   nu există date reale de OI/spread în `optionsAutomatedPortfolio.ts` — gol
   cunoscut, documentat explicit în cod lângă apelul `canTrade()`.
9. Politica de regim (banda Regime Score permite direcția și scorul minim de
   setup) — **depinde de un `regimeScore` live, care azi nu există** (vezi
   item 2 din §2 P0). Până atunci, parametrul opțional cade pe fallback-ul
   intern (70, Risk-on) — comportament identic cu înainte ca gate-ul să existe,
   deci nu e o regresie, dar nici protecție reală de regim încă.
10. Heartbeat worker în limită.

Returnează `{allow, sizeMultiplier, suggestedQty, checks, fails}` — tipul
exact e în `masterPlanCore.ts` (`GateResult`).

---

## 4. Persistență — traducere Firestore (nu Postgres)

`firestore.rules` acoperă azi doar `journalEntries` și `watchlistItems` (sub
`/users/{userId}/...`), validate cu funcții `isValidJournalEntry()`/
`isValidWatchlistItem()` + un deny-all implicit (`match /{document=**} {allow
read, write: if false;}`). Orice colecție nouă trebuie să urmeze **exact**
acest tipar — scoping per-utilizator, validare pe câmpuri, și testată (§5).

Colecții noi necesare (traducere a intenției din `trullas-schema-v3-delta.sql`,
fără să copiezi SQL-ul):

| Concept SQL vechi | Colecție Firestore nouă | Note |
|---|---|---|
| `bot_state` | `/users/{userId}` (document unic) | **Parțial există deja** — `firebase-blueprint.json` are deja schema `UserBotState` (`simCapitalUsd`, `maxRiskPerTradePct`, `dailyLossLimitPct`, `botStatus`). Extinde-l cu `maxSectorExposurePct`, `activeEpochId` ca să se potrivească 1:1 cu `MasterPlanSettings` din `masterPlanCore.ts`. |
| `signals` + `signal_outcomes` (shadow) | `/users/{userId}/signals/{signalId}` | Un document per semnal shadow; câmpuri: `symbol`, `setupType`, `confirmedBarTs`, `direction`, `levels` (obiectul `Levels` serializat), `outcome` (completat de outcome engine după ce bara se închide), `exitPolicyId`. |
| `exit_policies` | `/exit_policies/{policyId}` (colecție globală, nu per-user — politicile sunt partajate) | Versionează la schimbare (`X1_fixed_v2`), nu suprascrie una cu rezultate deja atașate — regula din plan §10 rămâne valabilă. |
| `bot_events` (heartbeat, kill switch, log de audit) | `/users/{userId}/botEvents/{eventId}` | Un document per eveniment; folosește pentru heartbeat-ul din verificarea #10 și pentru jurnalul „decizii blocate + motiv" cerut în plan §4.4 (AUTOPILOT) — exact log-urile `SKIP` pe care gate-ul le scrie deja în `AutomatedTradeLog`/`OptionsTradeLog` (§0.1); persistă-le aici, nu doar în memorie. |
| `universe_members` | `/universes/{universeId}/members/{symbol}` (colecție globală) | `universeId` ∈ `{sp500, ndx100, sp500_ndx100}`. |
| `strategy_stats` / view-urile `v_signal_*`, `v_journal_stats_*` | **Nu** o colecție 1:1 — Firestore nu are view-uri SQL. Fie (a) un document agregat per strategie (`/strategyStats/{strategyId}`), recalculat de un job server-side (în `server.ts`, pe același program Tier 1/Tier 2) din interogări pe `signals`/`journalEntries`, fie (b) calcul client-side pe un set mărginit (≤ ultimele N zile) la fiecare load, ca în prototipul HTML. Pentru orice KPI care trebuie să fie exact (CI90, profit factor cu prag n≥10), preferă (a) — un document recalculat de server, nu de fiecare client separat, ca să nu diverg rezultatele între utilizatori/sesiuni. |

Extinde `firestore.rules` cu validatoare noi (`isValidSignal()`,
`isValidBotEvent()`, etc.) după exact tiparul `isValidJournalEntry()` deja
existent, și extinde `firebase-blueprint.json` cu schemele noi, ca
documentație.

---

## 5. Cum validezi (replică rigoarea, nu o presupune)

Nu există Postgres, deci §4 din versiunea veche a acestui prompt
(`pglast`, `scipy`, RLS cu `set_config`) nu se aplică. Echivalentul pentru
Firebase + codul acestui proiect:

1. **Teste de logică (engine-uri, nu UI)**: `npx tsx --test
   src/utils/<fișier>.test.ts` — exact metoda folosită azi pentru toate
   fix-urile din §0.1 (nu necesită `npm install` complet pentru fișiere fără
   dependențe externe; pentru cele care importă `firebase` sau
   `@luxalgo/journal-core`, rulează `npm install` real întâi). Țintă: 0
   regresii față de rularea de bază (`npx tsx --test src/utils/*.test.ts`,
   azi 121/125, cele 4 eșecuri fiind de mediu).
2. **Teste ad-hoc de comportament determinist** pentru orice gate/regulă nouă
   — exact cum am verificat azi `canTrade()`: construiește două scenarii
   (condiție care ar trebui să blocheze, condiție care ar trebui să permită),
   rulează funcția, confirmă rezultatul **și motivul** (`gate.fails`), nu doar
   `allow`/`!allow`. Șterge scriptul ad-hoc după ce confirmi (nu-l lăsa în
   `src/`) — pune concluzia într-un test permanent dacă merită păstrat.
3. **Reguli Firestore, testate activ**: folosește Firebase Local Emulator
   Suite (`firebase emulators:start --only firestore`) + pachetul
   `@firebase/rules-unit-testing`. Pentru fiecare colecție nouă din §4,
   scrie minim: (a) un utilizator nu poate citi/scrie documentele altui
   utilizator (echivalentul testului de izolare RLS pe care l-am rulat eu pe
   Postgres, dar aici cu `assertFails()`/`assertSucceeds()` din acel pachet);
   (b) un document care încalcă `isValidX()` e respins la scriere.
4. **Paritate JS ↔ JS** (nu mai există JS ↔ SQL): dacă muți logica outcome
   engine din `trullasOutcomeEngine.ts` către persistență reală (§2, item 14),
   scrie un test care rulează aceleași semnale sintetice prin engine-ul live
   și confirmă aceleași rezultate ca varianta de referință
   `trullas-outcome-engine.js` (deja cross-validată, 72 comparații, 0
   diferențe) — nu recalcula de la zero fără acest test de paritate.
5. **Render-test vizual** pentru orice ecran nou sau modificat: screenshot
   headless (Playwright — deja preinstalat, nu rula `playwright install`) pe
   state înainte/după o schimbare (ex. schimbă capitalul/riscul din Settings,
   sau declanșează un `canTrade()` eșuat) și confirmă vizual că valorile
   afișate se mișcă corect — nu doar că pagina nu crapă.

Nu marca un item din §2 ca „done" fără pașii aplicabili lui din lista de mai
sus.

---

## 6. Ce NU faci

Din plan §10, plus ce am învățat azi:
- Nu adăuga simulare de portofoliu cu capital partajat între semnale
  simultane (P3).
- Nu amesteca surse de date pentru futures (Yahoo + Stooq) în același
  backtest.
- Nu reconstrui retroactiv P&L de opțiuni fără bid/ask înregistrat la
  momentul respectiv.
- Nu schimba parametrii unei politici de ieșire care are deja rezultate
  (versionează: `X1_fixed_v2`).
- **Nu reintroduce un al doilea store pentru același concept** (exact bug-ul
  `watchlist.ts` vs `watchlistManager.ts` reparat azi) — dacă ai nevoie de o
  variantă nouă a unei structuri de date existente, extinde modulul existent,
  nu crea un fișier paralel „v2" fără să-l migrezi pe cel vechi și să-l ștergi.
- **Nu forța o verificare generică peste un caz care nu i se potrivește
  semantic** fără să documentezi explicit de ce (exact ce am făcut la
  excepția options din verificarea #7, §3, item 17 din §2) — o excepție
  tăcută, nedocumentată, e mai periculoasă decât lipsa verificării.
- **Nu lăsa o verificare de stare (calendar, flag, sesiune) să ignore un flag
  deja existent al apelantului** (regula §1.9) — combină-le explicit.
- Nu restaura referințe la numele/marca „TrendSpider"/„Raindrop®" în UI sau
  cod până nu se ia decizia de la §2, P0, item 3.

---

## 7. Când ești blocat

Oprește-te și întreabă proprietarul — nu presupune — pentru:
- Orice item din „Întrebări deschise" (plan §11).
- **Decizia TrendSpider®** (`trullas-consolidation-map.md` §4.1) — risc
  potențial de marcă înregistrată; nu e o decizie tehnică.
- **Nivelul de fuziune UI** pentru clusterul Scanner/Confluence/Action-Zones/
  Today (map §4.2) — fuziune completă vs. separare parțială cu motor comun.
- Capitalul-țintă pentru live, broker-ul de opțiuni, dacă futures CME intră
  în P1 sau rămâne context.

Un ghicit greșit la `canTrade()`, la regula de mărime, sau la o decizie de
marcă înregistrată costă bani sau probleme legale reale mai târziu.
